"use client";

import React, { useMemo, useState } from "react";
import { buildLogicalMap } from "@/gaia/logicalMap/buildLogicalMap";

type Axial = { q: number; r: number };

function padRight(s: string, n: number) {
  if (s.length >= n) return s;
  return s + " ".repeat(n - s.length);
}

function cellLabel(cell: any, cellWidth: number) {
  if (!cell) return padRight(".", cellWidth);
  if (cell.kind === "planet") return padRight(String(cell.planetType ?? "PLANET"), cellWidth);
  if (cell.kind === "special") return padRight("SPECIAL", cellWidth);
  return padRight(".", cellWidth);
}

function renderHexDump(result: any, opts?: { cellWidth?: number; maxCols?: number }) {
  const cellWidth = Math.max(4, opts?.cellWidth ?? 8);
  const cellsByKey: Map<string, any> | undefined = result?.cellsByKey;
  const bounds = result?.bounds;
  if (!cellsByKey || !bounds) return "[no cells]";

  const minQ = Number(bounds.minQ ?? 0);
  const maxQ = Number(bounds.maxQ ?? 0);
  const minR = Number(bounds.minR ?? 0);
  const maxR = Number(bounds.maxR ?? 0);

  const maxCols = opts?.maxCols ?? 120;
  const qSpan = maxQ - minQ + 1;
  const approxLineLen = qSpan * (cellWidth + 1) + Math.abs(maxR - minR) * (cellWidth / 2);
  const warnHuge = approxLineLen > maxCols * 4;

  const lines: string[] = [];
  lines.push(
    `Legend: token=${cellWidth} chars, '.'=space/empty | q:[${minQ},${maxQ}] r:[${minR},${maxR}] cells=${cellsByKey.size}`
  );
  if (warnHuge) lines.push(`(note) dump may be wide; reduce zoom or adjust bounds/centers if needed.`);
  lines.push("");

  for (let r = minR; r <= maxR; r++) {
    const indentUnits = r - minR;
    const indent = " ".repeat(Math.floor((cellWidth / 2) * indentUnits));

    const rowTokens: string[] = [];
    for (let q = minQ; q <= maxQ; q++) {
      const k = `${q},${r}`;
      const cell = cellsByKey.get(k);
      rowTokens.push(cellLabel(cell, cellWidth));
    }
    lines.push(`${padRight(String(r), 4)}| ${indent}${rowTokens.join(" ")}`);
  }

  return lines.join("\n");
}

/**
 * Axial -> pixel (FLAT-TOP) using RedBlobGames convention.
 * This makes "columns" (constant q) align vertically, which matches the desired 3-4-5-4-3 silhouette.
 *
 * x = size * 3/2 * q
 * y = size * sqrt(3) * (r + q/2)
 */
function axialToPixelFlatTop(a: Axial, size: number) {
  const x = size * 1.5 * a.q;
  const y = size * Math.sqrt(3) * (a.r + a.q / 2);
  return { x, y };
}

function hexPointsFlatTop(cx: number, cy: number, size: number) {
  // flat-top hex: vertices at angles 0,60,120...
  const pts: Array<[number, number]> = [];
  for (let i = 0; i < 6; i++) {
    const angle = (Math.PI / 180) * (60 * i);
    pts.push([cx + size * Math.cos(angle), cy + size * Math.sin(angle)]);
  }
  return pts.map(([x, y]) => `${x.toFixed(2)},${y.toFixed(2)}`).join(" ");
}

function isPlanet(cell: any) {
  return cell && cell.kind === "planet";
}

function renderSvg(result: any, opts?: { size?: number; padding?: number; showAllCells?: boolean }) {
  const size = opts?.size ?? 26;
  const padding = opts?.padding ?? 40;
  const showAllCells = opts?.showAllCells ?? true;

  const cellsByKey: Map<string, any> | undefined = result?.cellsByKey;
  if (!cellsByKey) return null;

  const entries: Array<[string, any]> = [];
  cellsByKey.forEach((v, k) => {
    // For a cleaner "tile silhouette" view, you could switch showAllCells=false and draw only planet cells.
    if (showAllCells || isPlanet(v)) entries.push([k, v]);
  });

  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const [k] of entries) {
    const [qStr, rStr] = k.split(",");
    const q = Number(qStr), r = Number(rStr);
    const { x, y } = axialToPixelFlatTop({ q, r }, size);
    minX = Math.min(minX, x);
    minY = Math.min(minY, y);
    maxX = Math.max(maxX, x);
    maxY = Math.max(maxY, y);
  }

  const expandX = size * 2;
  const expandY = size * 2;
  minX -= expandX + padding;
  minY -= expandY + padding;
  maxX += expandX + padding;
  maxY += expandY + padding;

  const viewW = maxX - minX;
  const viewH = maxY - minY;

  return (
    <svg
      width="100%"
      height="auto"
      viewBox={`${minX} ${minY} ${viewW} ${viewH}`}
      style={{ border: "1px solid #ddd", borderRadius: 12, background: "#fff" }}
    >
      {entries.map(([k, cell]) => {
        const [qStr, rStr] = k.split(",");
        const q = Number(qStr), r = Number(rStr);
        const { x, y } = axialToPixelFlatTop({ q, r }, size);
        const pts = hexPointsFlatTop(x, y, size);

        const planet = isPlanet(cell);
        const stroke = planet ? "#111" : "#c7c7c7";
        const strokeW = planet ? 2.6 : 1.2;

        return (
          <g key={k}>
            <polygon points={pts} fill="#fff" stroke={stroke} strokeWidth={strokeW} />
            {planet && (
              <text
                x={x}
                y={y + 4}
                textAnchor="middle"
                fontSize={Math.max(10, size * 0.42)}
                fontFamily="system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif"
                fill="#111"
              >
                {String(cell.planetType)}
              </text>
            )}
          </g>
        );
      })}
    </svg>
  );
}

export default function Page() {
  const [seed, setSeed] = useState<string>("0");
  const [templateId, setTemplateId] = useState<string>("3p_lostFleet");
  const [result, setResult] = useState<any>(null);
  const [err, setErr] = useState<string>("");
  const [showAscii, setShowAscii] = useState<boolean>(false);
  const [showAllCells, setShowAllCells] = useState<boolean>(true);

  const collisions = result?.collisions ?? [];
  const collisionsBySlot: Record<string, number> = result?.collisionsBySlot ?? {};
  const collisionCount = result?.collisionCount ?? 0;

  const hexDump = useMemo(() => {
    if (!result) return "";
    return renderHexDump(result, { cellWidth: 9 });
  }, [result]);

  const svg = useMemo(() => {
    if (!result) return null;
    return renderSvg(result, { size: 26, padding: 40, showAllCells });
  }, [result, showAllCells]);

  return (
    <div style={{ padding: 16, fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif" }}>
      <h2>Logical Map – Debug</h2>

      <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
        <label>
          Template:
          <input
            value={templateId}
            onChange={(e) => setTemplateId(e.target.value)}
            style={{ marginLeft: 8, padding: 6, width: 180 }}
          />
        </label>

        <label>
          Seed:
          <input value={seed} onChange={(e) => setSeed(e.target.value)} style={{ marginLeft: 8, padding: 6, width: 120 }} />
        </label>

        <button
          onClick={() => {
            setErr("");
            try {
              const r = buildLogicalMap({ seed, templateId });
              setResult(r);
            } catch (e: any) {
              setResult(null);
              setErr(String(e?.message ?? e));
            }
          }}
          style={{ padding: "6px 12px" }}
        >
          Run
        </button>

        <label style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <input type="checkbox" checked={showAllCells} onChange={(e) => setShowAllCells(e.target.checked)} />
          Show all cells (else only planets)
        </label>

        <label style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <input type="checkbox" checked={showAscii} onChange={(e) => setShowAscii(e.target.checked)} />
          Show ASCII dump
        </label>
      </div>

      {err && (
        <pre style={{ marginTop: 12, background: "#2b0000", color: "#ffd0d0", padding: 12, overflow: "auto" }}>
          {err}
        </pre>
      )}

      {result && (
        <div style={{ marginTop: 16 }}>
          <h3>Summary</h3>
          <div>
            <strong>templateId:</strong> {result.templateId}{" "}
            <strong style={{ marginLeft: 12 }}>seed:</strong> {String(result.seed)}
          </div>
          <div style={{ marginTop: 6 }}>
            <strong>cells:</strong> {result.cellsByKey?.size ?? 0}{" "}
            <strong style={{ marginLeft: 12 }}>collisions:</strong> {collisionCount}
          </div>

          <h3 style={{ marginTop: 16 }}>Fine Board (Rendered – flat-top)</h3>
          <div style={{ maxWidth: 1200 }}>{svg}</div>

          {showAscii && (
            <>
              <h3 style={{ marginTop: 16 }}>Logical Map Dump (Hex-like ASCII)</h3>
              <pre style={{ background: "#0b1020", color: "#d7e3ff", padding: 12, overflow: "auto", maxHeight: 520 }}>
                {hexDump}
              </pre>
            </>
          )}

          <h3 style={{ marginTop: 16 }}>Collision Report</h3>

          <h4>By Slot (desc)</h4>
          <pre style={{ background: "#111", color: "#c8ffb0", padding: 12, overflow: "auto", maxHeight: 220 }}>
            {Object.entries(collisionsBySlot)
              .sort((a, b) => (b[1] ?? 0) - (a[1] ?? 0))
              .map(([slotId, count]) => `${slotId}: ${count}`)
              .join("\n") || "(none)"}
          </pre>

          <h4>Details (first 50)</h4>
          <pre style={{ background: "#111", color: "#9fe7ff", padding: 12, overflow: "auto", maxHeight: 420 }}>
            {collisions
              .slice(0, 50)
              .map((c: any, i: number) => {
                const A = c.a;
                const B = c.b;
                return [
                  `#${i + 1} at ${c.key}`,
                  ` A: ${A.slotId}/${A.sectorId} rot=${A.rot} local=${A.localKey} center=(${A.slotCenter.q},${A.slotCenter.r})`,
                  ` B: ${B.slotId}/${B.sectorId} rot=${B.rot} local=${B.localKey} center=(${B.slotCenter.q},${B.slotCenter.r})`,
                  "",
                ].join("\n");
              })
              .join("\n") || "(none)"}
          </pre>
        </div>
      )}
    </div>
  );
}
