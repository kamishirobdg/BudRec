"use client";

// Normalize a rotation value into 0..5.
// Defensive against NaN/Infinity/undefined inputs.
function rot6(rot: unknown): number {
  const n = typeof rot === "number" ? rot : Number(rot);
  if (!Number.isFinite(n)) return 0;
  const r = n % 6;
  return r < 0 ? r + 6 : r;
}

// ===== Middle tile offsets (fixed by rot; tuning target) =====
const MIDDLE_TILE_OFFSETS: Record<number, { x: number; y: number }> = {
  0: { x: 22, y: -1 },
  1: { x: 12, y: 18 },
  2: { x: -9, y: 18 },
  3: { x: -21, y: 1 },
  4: { x: -11, y: -18 },
  5: { x: 10, y: -18 },
};

// Middle tile image baseline differs from logic/text by -120° in current assets.
// Apply a fixed rot offset ONLY for image drawing & image-offset lookup.
const MIDDLE_DRAW_ROT_OFFSET = 4; // +4*60° = 240° = -120°


import React, { useEffect, useMemo, useRef, useState } from "react";
import type { Cell, PlanetType } from "../GAIA/sectorTypes";
import { BASE_SECTORS } from "../GAIA/sectorTiles_base";
import { EXPANSION_TILES_ALL, EXPANSION_MIDDLE_IDS, EXPANSION_LITTLE_IDS, EXPANSION_SCOUT_IDS } from "../GAIA/sectorTiles_expansion";
import { findForbiddenProximityPairs } from "../GAIA/fineConstraints";
import { axialToPixel, hexPoints, parseKey, type HexOrientation } from "../GAIA/hexLayout";
import { rotate60 } from "../GAIA/axialMath";
import { buildLogicBoardWithLocalColumnShift, type SectorPlacement } from "../GAIA/boardTransforms";

import type { ExpansionKind, MapLayoutTemplate, SlotAssignment, TemplateTags } from "../GAIA/mapTemplates";
import { makeTemplateId, placementsFromTemplate } from "../GAIA/mapTemplates";
import { deleteTemplate, loadTemplates, saveTemplates, upsertTemplate } from "../GAIA/templateStore";
import { validateAssigns } from "../GAIA/assignRules";
import { appendHistoryEntry } from "../GAIA/historyStore";
import type { PersistedAssigns } from "../GAIA/types";

import { SCORE_MAPS_BY_TEMPLATE } from "../GAIA/scoreMaps";

type SlotEditMode = "none" | "editPos";

const ORIENTATION: HexOrientation = "flat";
const VIEW_ROT60 = 4; // 240°
const VIEW_MIRROR = false;

// 3rd:+1, 4th:+1, 5th:+2
const RULE = { shiftsByIndex1: { 3: 1, 4: 1, 5: 2 } } as const;

const SECTOR_IDS_BASE = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10"] as const;
// 3P fixed pool: exclude 08, and use alternate variants for 05/06/07.
// If the alternate ids/images/defs are not present, we gracefully fall back to the base ids.
const SECTOR_IDS_3P_FIXED = ["01", "02", "03", "04", "05b", "06b", "07b", "09", "10"] as const;
type SectorId = string;
function planetLabel(cell: Cell): string {
  return cell.kind === "planet" ? cell.planet : "";
}


function tileIdFromCell(cell: Cell): string {
  const tag = cell.tags?.find((t) => t.startsWith("tile:"));
  return tag ? tag.slWHITE("tile:".length) : "?";
}

function defaultPlacement(): SectorPlacement {
  return { sectorId: "01", pos: { q: 0, r: 0 }, rot: 0 };
}

function getSectorPoolForTemplate(tpl: MapLayoutTemplate | null): readonly string[] {
  if (tpl?.tags.players === 3) return SECTOR_IDS_3P_FIXED;
  return SECTOR_IDS_BASE;
}


function getTilePoolForSlot(tpl: MapLayoutTemplate, kind: string): readonly string[] {
  // SECTOR は従来どおり base pool
  if (kind === 'MIDDLE') return EXPANSION_MIDDLE_IDS;
  if (kind === 'SMALL') return [...EXPANSION_SCOUT_IDS, ...EXPANSION_LITTLE_IDS];
  return getSectorPoolForTemplate(tpl);
}

function hasKnownTileDefId(sectorId: string): boolean {
  // Logic side must keep exact ids for expansion tiles (11a etc).
  if (BASE_SECTORS.some((s) => s.id === sectorId)) return true;
  if ((EXPANSION_MIDDLE_IDS as readonly string[]).includes(sectorId)) return true;
  if ((EXPANSION_LITTLE_IDS as readonly string[]).includes(sectorId)) return true;
  if ((EXPANSION_SCOUT_IDS as readonly string[]).includes(sectorId)) return true;
  return false;
}

/**
 * IMPORTANT:
 * - Logic/board building MUST keep exact ids for expansion tiles (e.g., 11a, 12b).
 * - Some legacy/experimental ids may have suffix like "05b"; those should be normalized only
 *   for BASE sectors (01..10) so that lookup matches defs.
 */
function normalizeSectorIdForLogic(sectorId: string): string {
  if (hasKnownTileDefId(sectorId)) return sectorId;
  const m = /^([0-9]{2})[a-z]$/.exec(sectorId);
  if (m) {
    const n = Number(m[1]);
    // Only normalize base sectors. Never touch expansion ids like 11a/12b.
    if (Number.isFinite(n) && n >= 1 && n <= 10) return m[1];
  }
  return sectorId;
}

function normalizeSectorIdForAssets(sectorId: string): string {
  // For assets, prefer exact when known.
  if (hasKnownTileDefId(sectorId)) return sectorId;
  // Fallback for legacy like 05b -> 05 (image exists as base)
  const m = /^([0-9]{2})[a-z]$/.exec(sectorId);
  if (m) return m[1];
  return sectorId;
}

function defaultAssignFromPool(i: number, pool?: readonly string[]): SlotAssignment {
  const p = pool && pool.length > 0 ? pool : SECTOR_IDS_BASE;
  return { sectorId: p[i % p.length] as any, rot: 0 };
}

function randInt(minIncl: number, maxIncl: number): number {
  const r = Math.random();
  return Math.floor(r * (maxIncl - minIncl + 1)) + minIncl;
}

function shuffle<T>(arr: readonly T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = randInt(0, i);
    const tmp = a[i];
    a[i] = a[j];
    a[j] = tmp;
  }
  return a;
}

type PosDraft = { q: string; r: string };

type TryResult =
  | {
      ok: true;
      assigns: SlotAssignment[];
      attemptsUsed: number;
      scoreTotal: number;
      balanceL1?: number;
      planetScores: Record<PlanetType, number>;
    }
  | {
      ok: false;
      reason: string;
      attemptsUsed: number;
      scoreTotal?: number;
      balanceL1?: number;
    };

type HistoryItem = {
  id: string;
  atIso: string;
  attemptsUsed: number;
  scoreTotal: number;
  balanceL1?: number;
  assigns: SlotAssignment[];
};

function isoNow(): string {
  return new Date().toISOString();
}


function needsSlotSanitize(tpl: MapLayoutTemplate): boolean {
  const slots = tpl.slots ?? [];
  if (slots.length === 0) return false;

  for (const s of slots) {
    const q = Number((s as any)?.pos?.q);
    const r = Number((s as any)?.pos?.r);
    if (!Number.isFinite(q) || !Number.isFinite(r)) return true;
    // 異常値（スクショの -300 など）を検知して救済
    if (Math.abs(q) > 50 || Math.abs(r) > 50) return true;
  }

  return false;
}

function recenterSlotsToOrigin(tpl: MapLayoutTemplate): MapLayoutTemplate {
  const slots = tpl.slots ?? [];
  if (slots.length === 0) return tpl;

  const sumQ = slots.reduce((a, s) => a + Number((s as any).pos.q), 0);
  const sumR = slots.reduce((a, s) => a + Number((s as any).pos.r), 0);
  const avgQ = sumQ / slots.length;
  const avgR = sumR / slots.length;

  const dq = Math.round(avgQ);
  const dr = Math.round(avgR);

  const nextSlots = slots.map((s) => ({
    ...s,
    pos: { q: Number((s as any).pos.q) - dq, r: Number((s as any).pos.r) - dr },
  }));

  return {
    ...tpl,
    slots: nextSlots as any,
    updatedAtIso: isoNow(),
  };
}

function shortIso(iso: string): string {
  // YYYY-MM-DD HH:mm:ss
  return iso.replace("T", " ").replace("Z", "").slWHITE(0, 19);
}


type SlotConstraint3pMode =
  | "NONE"
  | "ALL_147_IN_1_4"
  | "AT_LEAST2_147_IN_1_4"
  | "SLOT4_AND_ONE_OF_1OR7_IN_1_4"
  | "SLOT4_MUST_IN_1_4";

function check3pSlotConstraint(
  mode: SlotConstraint3pMode,
  assigns: SlotAssignment[]
): { ok: true } | { ok: false; reason: string } {
  if (mode === "NONE") return { ok: true };

  // 3P slots are fixed; interpret slot1/4/7 as indWHITEs 0/3/6 (1-indexed 1/4/7).
  const idx1 = 0;
  const idx4 = 3;
  const idx7 = 6;

  const id1 = assigns[idx1]?.sectorId;
  const id4 = assigns[idx4]?.sectorId;
  const id7 = assigns[idx7]?.sectorId;

  if (!id1 || !id4 || !id7) {
    return { ok: false, reason: "slotConstraint:missingSlots" };
  }

  const isIn14 = (id: string) =>
    id === "01" || id === "02" || id === "03" || id === "04";

  const c147 = Number(isIn14(id1)) + Number(isIn14(id4)) + Number(isIn14(id7));

  switch (mode) {
    case "ALL_147_IN_1_4":
      return c147 === 3 ? { ok: true } : { ok: false, reason: "slotConstraint:all(1,4,7)in1-4" };

    case "AT_LEAST2_147_IN_1_4":
      return c147 >= 2 ? { ok: true } : { ok: false, reason: "slotConstraint:atLeast2(1,4,7)in1-4" };

    case "SLOT4_AND_ONE_OF_1OR7_IN_1_4": {
      if (!isIn14(id4)) return { ok: false, reason: "slotConstraint:slot4NotIn1-4" };
      if (isIn14(id1) || isIn14(id7)) return { ok: true };
      return { ok: false, reason: "slotConstraint:slot4NeedsSlot1or7In1-4" };
    }

    case "SLOT4_MUST_IN_1_4":
      return isIn14(id4) ? { ok: true } : { ok: false, reason: "slotConstraint:slot4MustIn1-4" };

    default:
      return { ok: true };
  }
}

type DraftScoreMap = Record<string, number>;

// ---------------------------
// Scoring helpers (absolute scoreMap + SWAMP proximity bonus)
// Rule: for each non-(TRANSDIM/SWAMP) planet cell, add +1 per SWAMP within dist<=2.
// This bonus is counted toward BOTH total and balance metrics.
// ---------------------------
const SCORE_TYPES: PlanetType[] = ["BLUE", "YELLOW", "BROWN", "RED", "WHITE", "ORANGE", "TRANSDIM"];

function axialDist(a: { q: number; r: number }, b: { q: number; r: number }): number {
  const aq = a.q, ar = a.r, as_ = -a.q - a.r;
  const bq = b.q, br = b.r, bs_ = -b.q - b.r;
  return Math.max(Math.abs(aq - bq), Math.abs(ar - br), Math.abs(as_ - bs_));
}

function computeSwampBonusByType(
  cells: Map<string, Cell>,
  opts: { enableDist2: boolean; enableDist1Extra: boolean }
): { bonusByType: Record<string, number>; swampTilesByType: Record<string, string[]> } {
  const swamps: { key: string; q: number; r: number; tileId: string }[] = [];
  for (const [k, c] of cells.entries()) {
    if (c.kind === "planet" && c.planet === "SWAMP") {
      const a = parseKey(k);
        if (!Number.isFinite((a as any)?.q) || !Number.isFinite((a as any)?.r)) return;
      swamps.push({ key: k, q: a.q, r: a.r, tileId: tileIdFromCell(c) });
    }
  }

  const bonusByType: Record<string, number> = {};
  const swampTilesSetByType: Record<string, Set<string>> = {};
  for (const t of SCORE_TYPES) {
    bonusByType[t] = 0;
    swampTilesSetByType[t] = new Set();
  }

  if (swamps.length === 0) {
    const swampTilesByType: Record<string, string[]> = {};
    for (const t of SCORE_TYPES) swampTilesByType[t] = [];
    return { bonusByType, swampTilesByType };
  }

  for (const [k, c] of cells.entries()) {
    if (c.kind !== "planet") continue;
    const pt = c.planet as PlanetType;
    if (!SCORE_TYPES.includes(pt)) continue;

    const a = parseKey(k);
        if (!Number.isFinite((a as any)?.q) || !Number.isFinite((a as any)?.r)) return;
    let bonus = 0;

    for (const s of swamps) {
      const d = axialDist(a, { q: s.q, r: s.r });

      if (opts.enableDist2 && d <= 2) {
        bonus += 1;
        swampTilesSetByType[pt].add(s.tileId);
      }
      if (opts.enableDist1Extra && d <= 1) {
        bonus += 1;
        swampTilesSetByType[pt].add(s.tileId);
      }
    }

    if (bonus !== 0) bonusByType[pt] += bonus;
  }

  const swampTilesByType: Record<string, string[]> = {};
  for (const t of SCORE_TYPES) swampTilesByType[t] = Array.from(swampTilesSetByType[t]).sort();

  return { bonusByType, swampTilesByType };
}

function computeScoreAndBalance(
  cells: Map<string, Cell>,
  cellScoreMap: DraftScoreMap | null,
  opts: {
    enableSwampDist2: boolean;
    enableSwampDist1Extra: boolean;
    neighborScoreMode: "off" | "count" | "diversity" | "count+diversity";
    TRANSDIMNeighborMode: "same" | "half" | "off";
    neighborRequireNonNegativeCellScore: boolean;
    neighborWCount: number;
    neighborWType: number;
  }
): {
  grandTotal: number;
  balanceL1: number;
  totalByType: Record<string, number>;
  // audit
  baseByTileByType: Record<string, Record<string, number>>;
  swampTilesByType: Record<string, string[]>;
  swampBonusByType: Record<string, number>;
  neighborByTileByType: Record<string, Record<string, { n: number; u: number; types: Set<string>; points: number }>>;
  neighborSumByType: Record<string, number>;
} {
  const baseSumByType: Record<string, number> = {};
  const baseByTileByType: Record<string, Record<string, number>> = {};
  for (const t of SCORE_TYPES) {
    baseSumByType[t] = 0;
    baseByTileByType[t] = {};
  }

  // Base (scoreMap) — non-zero only for tile breakdown
  for (const [k, c] of cells.entries()) {
    if (c.kind !== "planet") continue;
    const pt = c.planet as PlanetType;
    if (!SCORE_TYPES.includes(pt)) continue;

    const v = cellScoreMap?.[k] ?? 0;
    baseSumByType[pt] += v;

    if (v !== 0) {
      const tid = tileIdFromCell(c);
      baseByTileByType[pt][tid] = (baseByTileByType[pt][tid] ?? 0) + v;
    }
  }

  // SWAMP bonus
  const swamp = computeSwampBonusByType(cells, {
    enableDist2: opts.enableSwampDist2,
    enableDist1Extra: opts.enableSwampDist1Extra,
  });
  const swampBonusByType = swamp.bonusByType;
  const swampTilesByType = swamp.swampTilesByType;

  // Neighbor scoring (aggregated by anchor tile id, attributed to anchor planet type)
  // Neighbor scoring (aggregated by anchor tile id, attributed to anchor planet type)
  // TRANSDIM is always excluded from anchors, but can be counted as neighbor depending on TRANSDIMNeighborMode.
  type NeighborRow = { n: number; u: number; types: Set<string>; points: number };
  const neighborByTileByType: Record<string, Record<string, NeighborRow>> = {};
  const neighborSumByType: Record<string, number> = {};
  for (const t of SCORE_TYPES) {
    neighborByTileByType[t] = {};
    neighborSumByType[t] = 0;
  }

  const TRANSDIMWeight = opts.TRANSDIMNeighborMode === "half" ? 0.5 : 1.0;

  const typeWeight = (planet: string): number => {
    if (planet === "TRANSDIM") return TRANSDIMWeight;
    return 1.0;
  };

  const shouldCountNeighborPlanet = (key: string, cell: Cell): boolean => {
    if (cell.kind !== "planet") return false;
    if (cell.planet === "SWAMP") return false;
    if (cell.planet === "TRANSDIM" && opts.TRANSDIMNeighborMode === "off") return false;
    if (opts.neighborRequireNonNegativeCellScore) {
      const v = cellScoreMap?.[key] ?? 0;
      if (v < 0) return false;
    }
    return true;
  };

  const shouldUseAsAnchor = (key: string, cell: Cell): boolean => {
    if (cell.kind !== "planet") return false;
    const pt = cell.planet as PlanetType;
    if (!SCORE_TYPES.includes(pt)) return false;
    const v = cellScoreMap?.[key] ?? 0; // undefined => 0
    return v >= 0;
  };

  const uFromTypes = (types: Set<string>): number => {
    let s = 0;
    for (const t of types) s += typeWeight(t);
    return s;
  };

  for (const [ak, ac] of cells.entries()) {
    if (!shouldUseAsAnchor(ak, ac)) continue;
    const anchorType = ac.planet as PlanetType;
    const anchorTileId = tileIdFromCell(ac);
    const a = parseKey(ak);

    let n = 0;
    const types = new Set<string>();

    for (const [bk, bc] of cells.entries()) {
      if (bk === ak) continue;
      if (!shouldCountNeighborPlanet(bk, bc)) continue;

      const b = parseKey(bk);
      if (axialDist(a, b) <= 2) {
        const p = (bc as any).planet as string;
        n += typeWeight(p);
        types.add(p);
      }
    }

    const u = uFromTypes(types);

    let points = 0;
    switch (opts.neighborScoreMode) {
      case "off":
        points = 0;
        break;
      case "count":
        points = opts.neighborWCount * n;
        break;
      case "diversity":
        points = opts.neighborWType * u;
        break;
      case "count+diversity":
        points = opts.neighborWCount * n + opts.neighborWType * u;
        break;
    }

    if (points !== 0) {
      neighborSumByType[anchorType] += points;

      const row = neighborByTileByType[anchorType][anchorTileId] ?? { n: 0, u: 0, types: new Set<string>(), points: 0 };
      row.n += n;
      for (const t of types) row.types.add(t);
      row.u = uFromTypes(row.types);
      row.points += points;

      neighborByTileByType[anchorType][anchorTileId] = row;
    }
  }
// Totals by type (includes neighbor, and used for balance)
  const totalByType: Record<string, number> = {};
  for (const t of SCORE_TYPES) {
    totalByType[t] = (baseSumByType[t] ?? 0) + (swampBonusByType[t] ?? 0) + (neighborSumByType[t] ?? 0);
  }

  const vals = SCORE_TYPES.map((t) => totalByType[t] ?? 0);
  const mean = vals.reduce((s, v) => s + v, 0) / vals.length;

  const mad = vals.reduce((s, v) => s + Math.abs(v - mean), 0) / vals.length;
  const avgAbs = vals.reduce((s, v) => s + Math.abs(v), 0) / vals.length;
  const denom = avgAbs > 1e-9 ? avgAbs : 1;
  const balanceL1 = mad / denom;

  const grandTotal = vals.reduce((s, v) => s + v, 0);
  return {
    grandTotal,
    balanceL1,
    totalByType,
    baseByTileByType,
    swampTilesByType,
    swampBonusByType,
    neighborByTileByType,
    neighborSumByType,
  };
}

// ---------------------------
// Template-scoped settings (localStorage)
// ---------------------------
type TemplateSettings = {
  balanceMaxL1?: number;
  scoreThreshold?: number;
};

const SETTINGS_KEY_PREFIX = "TRANSDIM:templateSettings:v1:";

function loadTemplateSettings(templateId: string): TemplateSettings | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(SETTINGS_KEY_PREFIX + templateId);
    if (!raw) return null;
    const obj = JSON.parse(raw) as TemplateSettings;
    if (!obj || typeof obj !== "object") return null;
    return obj;
  } catch {
    return null;
  }
}

function saveTemplateSettings(templateId: string, next: TemplateSettings) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(SETTINGS_KEY_PREFIX + templateId, JSON.stringify(next));
  } catch {
    // ignore (storage blocked / quota)
  }
}

export default function MapViewer() {

  // Sectors with tile tags (base + expansion)
  const SECTORS_WITH_TILE_TAG = useMemo(() => {
    const base = BASE_SECTORS.map((s) => ({
      ...s,
      cells: Object.fromEntries(
        Object.entries(s.cells).map(([k, c]) => [
          k,
          {
            ...c,
            tags: Array.from(new Set([...(c.tags ?? []), `tile:${s.id}`])),
          },
        ])
      ) as any,
    }));

    // Expansion tiles are sparse (footprint: tri3/single). Convert them into SectorTileDef-like
    // dense records so boardTransforms can iterate with Object.entries(def.cells) using "q,r" keys.
    // NOTE: Leaving them sparse (cells as array) causes parseKey("0") -> r=NaN -> "NaN,NaN" collisions.
    const exp = (EXPANSION_TILES_ALL as any[]).map((t) => {
      const dense: Record<string, any> = {};
      for (const sc of (t.cells ?? [])) {
        const at = (sc as any)?.at;
        const cell = (sc as any)?.cell;
        if (!at || !Number.isFinite(at.q) || !Number.isFinite(at.r) || !cell) continue;
        const k = `${at.q},${at.r}`;
        dense[k] = {
          ...cell,
          tags: Array.from(new Set([...(cell.tags ?? []), `tile:${t.id}`])),
        };
      }
      return {
        id: t.id,
        // radius isn't used by boardTransforms, but keep a sensible placeholder.
        radius: 0,
        cells: dense,
      };
    });

    return [...base, ...exp] as any;
  }, []);

  // Edit: placements を直接編集（Freeze元）
  const [placements, setPlacements] = useState<SectorPlacement[]>([defaultPlacement()]);

  // Templates
  const [templates, setTemplates] = useState<MapLayoutTemplate[]>([]);
  const [activeTemplateId, setActiveTemplateId] = useState<string>("");

  // Filters (optional)
  const [filterPlayers, setFilterPlayers] = useState<3 | 4 | "all">("all");
  const [filterExp, setFilterExp] = useState<ExpansionKind | "all">("all");
  // Assigns (template mode): length matches template.slots; sectorId=="" means unassigned
  const [assigns, setAssigns] = useState<SlotAssignment[]>([]);
  // A案: Assign UI is 0-start; manage visible slot indWHITEs (slotIndex only)
  const [visibleAssignSlotIndWHITEs, setVisibleAssignSlotIndWHITEs] = useState<number[]>([]);

  // Assign欄から slot.pos を直接入力して更新するためのドラフト（slotIndex -> {q,r}）
  const [posDraftBySlot, setPosDraftBySlot] = useState<Record<number, PosDraft>>({});

  // Slot position editor (A方式)
  const [slotEditMode, setSlotEditMode] = useState<SlotEditMode>("none");
  const [editingSlotIndex, setEditingSlotIndex] = useState<number | null>(null);

  // Freeze form
  const [freezeLabel, setFreezeLabel] = useState<string>("My Layout");
  const [freezePlayers, setFreezePlayers] = useState<3 | 4>(4);
  const [freezeExp, setFreezeExp] = useState<ExpansionKind>("base");

  // Randomize status
  const [randomizeStatus, setRandomizeStatus] = useState<string>("");
  const [lastAttempts, setLastAttempts] = useState<number>(0);

  // Search session status (infinite search + stop)
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const stopSearchRef = useRef<boolean>(false);
  const [searchElapsedMs, setSearchElapsedMs] = useState<number>(0);
  const [searchSpeed, setSearchSpeed] = useState<number>(0);
  const [lastRejectReason, setLastRejectReason] = useState<string>("");

  // Max attempts (configurable)
  const [maxAttempts, setMaxAttempts] = useState<number>(0); // 0 = infinite

  // Search mode: stop on first hit or keep running until user stops
  type SearchMode = "single" | "continuous";
  const [searchMode, setSearchMode] = useState<SearchMode>("single");

  // 3P Slot constraint (5-choWHITE)
  const [slotConstraint3p, setSlotConstraint3p] = useState<SlotConstraint3pMode>("NONE");

  type RenderMode = "cells" | "tiles";
  const [renderMode, setRenderMode] = useState<RenderMode>("tiles");

  

  // Tile rendering calibration
  // - Keep SECTOR tiles on the legacy/default settings
  // - Apply tuning ONLY to MIDDLE tiles (user request)
  const SECTOR_TILE_IMG_FACTOR = 8.6;

  // Middle tile size factor (relative to hex size)
  const [middleTileImgFactor, setMiddleTileImgFactor] = useState<number>(3.5);

  // Middle tile pixel offset (to align with the "cells" view)
  const [middleTileOffsetX, setMiddleTileOffsetX] = useState<number>(0);
  const [middleTileOffsetY, setMiddleTileOffsetY] = useState<number>(0);


  // Tile rotation calibration (because SVG rotate direction differs from axial CCW)
  // dir: -1 to flip rotation direction, offset60: additional 60° steps, offsetDeg: fine offset in degrees
  const [tileRotDir, setTileRotDir] = useState<1 | -1>(1);
  const [tileRotOffset60, setTileRotOffset60] = useState<number>(2);
  const [tileRotOffsetDeg, setTileRotOffsetDeg] = useState<number>(0);


  // Global rotation applied to the whole tile map (60° steps). Use this to match the "cells" orientation perfectly.
  const [tileMapRot60, setTileMapRot60] = useState<number>(0);
// --- Thresholds ---
  // Total score threshold: reject if total > threshold (existing behavior)
  const [scoreThreshold, setScoreThreshold] = useState<number>(999999);

  // Balance threshold: reject if L1 > balanceMaxL1
  // Default requested: 0.75
  const [balanceMaxL1, setBalanceMaxL1] = useState<number>(0.75);
  // --- Neighbor scoring toggles ---
  type NeighborScoreMode = "off" | "count" | "diversity" | "count+diversity";
  const [neighborScoreMode, setNeighborScoreMode] = useState<NeighborScoreMode>("count+diversity");

  // Swamp bonus toggles (affects PlanetType scoring; audit shows tile IDs)
  const [enableSwampDist2, setEnableSwampDist2] = useState<boolean>(true);
  const [enableSwampDist1Extra, setEnableSwampDist1Extra] = useState<boolean>(true);
  type TRANSDIMNeighborMode = "same" | "half" | "off";
  // TRANSDIM の近傍評価での扱い：same=通常(1.0), half=0.5, off=カウントしない
  const [TRANSDIMNeighborMode, setTRANSDIMNeighborMode] = useState<TRANSDIMNeighborMode>("same");
  const [neighborRequireNonNegativeCellScore, setNeighborRequireNonNegativeCellScore] = useState<boolean>(true);
  const [neighborWCount, setNeighborWCount] = useState<number>(1);
  const [neighborWType, setNeighborWType] = useState<number>(1);


  // History
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const HISTORY_MAX = 20;

  // --- Picking UI（座標採点のクリック取得） ---
  const [draftScoreByTemplate, setDraftScoreByTemplate] = useState<Record<string, DraftScoreMap>>({});
  const [pickedKeys, setPickedKeys] = useState<Set<string>>(new Set());
  const [pickValue, setPickValue] = useState<number>(1);
  const [pickStatus, setPickStatus] = useState<string>("");

  // 追加：ホバー中セルの可視化
  const [hoverKey, setHoverKey] = useState<string>("");  const [auditSelectedType, setAuditSelectedType] = useState<string>("BLUE");


  // Hydration safety: render SVG only after mount
  const [mounted, setMounted] = useState(false);
const sanitizedTemplateIdsRef = useRef<Set<string>>(new Set());
  useEffect(() => setMounted(true), []);

  useEffect(() => {
    const ts = loadTemplates();
    setTemplates(ts);
    if (ts.length > 0) setActiveTemplateId(ts[0].id);
  }, []);

  const activeTemplate = useMemo(
    () => templates.find((t) => t.id === activeTemplateId) ?? null,
    [templates, activeTemplateId]
  );


  // Safety net: 既存localStorage等で slot.pos が破損している場合、表示不能になるため、
  // activeTemplate 読み込み直後に一度だけ recenter して救済する（平行移動のみ）。
  useEffect(() => {
    if (!activeTemplate) return;
    if (sanitizedTemplateIdsRef.current.has(activeTemplate.id)) return;
    if (!needsSlotSanitize(activeTemplate)) return;

    sanitizedTemplateIdsRef.current.add(activeTemplate.id);
    const fixed = recenterSlotsToOrigin(activeTemplate);

    // state + storage を同期更新（最小）
    setTemplates((prev) => prev.map((t) => (t.id === fixed.id ? fixed : t)));
    try {
      upsertTemplate(fixed);
    } catch {
      // ignore
    }
  }, [activeTemplateId, activeTemplate]);

  const assignValidation = useMemo(() => {
    if (!activeTemplate) return { ok: true, errors: [] as { message: string }[] };
    const bySlotIndex: Record<number, string | undefined> = {};
    const n = activeTemplate.slots?.length ?? 0;
    for (let i = 0; i < n; i++) {
      const id = assigns[i]?.sectorId;
      bySlotIndex[i] = id && id.trim() !== "" ? id : undefined;
    }
    return validateAssigns(activeTemplate, bySlotIndex);
  }, [activeTemplate, assigns]);



  function updateTemplateSlotPos(slotIndex: number, pos: { q: number; r: number }) {
    if (!activeTemplate) return;

    const next: MapLayoutTemplate = {
      ...activeTemplate,
      slots: activeTemplate.slots.map((s, i) => (i === slotIndex ? { ...s, pos } : s)),
      meta: activeTemplate.meta ?? {},
    };

    // templateStore へ保存 + 画面 state を更新
    const nextList = upsertTemplate(next);
    setTemplates(nextList);
    setActiveTemplateId(next.id);
  }

  // Assign欄の入力を activeTemplate の現在値で初期化（visibleなslotのみ）
  useEffect(() => {
    if (!activeTemplate) {
      setPosDraftBySlot({});
      return;
    }
    const indWHITEs = visibleAssignSlotIndWHITEs.slWHITE();
    setPosDraftBySlot((prev) => {
      const next = { ...prev };
      for (const idx of indWHITEs) {
        const s: any = activeTemplate.slots[idx];
        const pos = s?.pos ?? s;
        if (!next[idx]) {
          next[idx] = { q: String(pos?.q ?? 0), r: String(pos?.r ?? 0) };
        }
      }
      return next;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTemplateId, visibleAssignSlotIndWHITEs.join(",")]);

  function applyPosDraft(slotIndex: number) {
    if (!activeTemplate) return;
    const d = posDraftBySlot[slotIndex];
    if (!d) return;
    const q = Number(d.q);
    const r = Number(d.r);
    if (!Number.isFinite(q) || !Number.isFinite(r)) return;
    updateTemplateSlotPos(slotIndex, { q: Math.trunc(q), r: Math.trunc(r) });
  }



  // activeTemplate が変わったら assigns を初期化
  // base: 従来どおり全slotをデフォルトで埋める
  // exp : A案の前提として SECTOR を空で開始（Assign UIは0件スタート）
  useEffect(() => {
    if (!activeTemplate) {
      setAssigns([]);
      setVisibleAssignSlotIndWHITEs([]);
      return;
    }

    setAssigns(() => {
      const out: SlotAssignment[] = [];
      const pool = getSectorPoolForTemplate(activeTemplate);
      const isExp = activeTemplate.tags?.expansion === 'exp';

      for (let i = 0; i < activeTemplate.slots.length; i++) {
        if (isExp) {
          // A案: Expansionテンプレ作成は「空から積み上げ」前提。
          // kind(SECTOR/MIDDLE/SMALL)に関わらず初期は空にして、必要なslotだけ Add〜 で表示して入力する。
          out.push({ sectorId: '', rot: 0 } as any);
          continue;
        }
        out.push(defaultAssignFromPool(i, pool));
      }
      return out;
    });

    // Assign UIの初期表示
    if (activeTemplate.tags?.expansion === 'exp') {
      setVisibleAssignSlotIndWHITEs([]);
    } else {
      setVisibleAssignSlotIndWHITEs([...Array(activeTemplate.slots.length).keys()]);
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTemplateId]);

  // テンプレ切替時にピック選択はクリア
  useEffect(() => {
    setPickedKeys(new Set());
    setPickStatus("");
    setHoverKey("");
  }, [activeTemplateId]);

  // テンプレ切替時に、テンプレ別設定を復元（なければデフォルト）
  useEffect(() => {
    if (!activeTemplateId) return;

    const st = loadTemplateSettings(activeTemplateId);
    if (!st) {
      // No saved settings: keep current defaults (0.75 / 999999)
      return;
    }
    if (typeof st.balanceMaxL1 === "number") setBalanceMaxL1(st.balanceMaxL1);
    if (typeof st.scoreThreshold === "number") setScoreThreshold(st.scoreThreshold);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTemplateId]);

  // 設定変更時にテンプレ別保存（activeTemplateId があるときのみ）
  useEffect(() => {
    if (!activeTemplateId) return;
    saveTemplateSettings(activeTemplateId, { balanceMaxL1, scoreThreshold });
  }, [activeTemplateId, balanceMaxL1, scoreThreshold]);

  const filteredTemplates = useMemo(() => {
    return templates.filter((t) => {
      if (filterPlayers !== "all" && t.tags.players !== filterPlayers) return false;
      if (filterExp !== "all" && t.tags.expansion !== filterExp) return false;
      return true;
    });
  }, [templates, filterPlayers, filterExp]);

  function updatePlacement(idx: number, next: SectorPlacement) {
    setPlacements((prev) => prev.map((p, i) => (i === idx ? next : p)));
  }
  function addPlacement() {
    setPlacements((prev) => [...prev, { sectorId: "02", pos: { q: 5, r: 0 }, rot: 0 }]);
  }
  function removePlacement(idx: number) {
    setPlacements((prev) => prev.filter((_, i) => i !== idx));
  }

  // --- no-dup sectorId: 重複が発生する指定をしたら swap で解決する ---
  function updateAssignNoDup(idx: number, next: SlotAssignment) {
    setAssigns((prev) => {
      const out = [...prev];

      const newId = String(next.sectorId ?? '');
      // empty は重複チェック対象外
      if (newId.length > 0) {
        const hit = out.findIndex((a, i) => i !== idx && String(a?.sectorId ?? '') === newId);
        if (hit >= 0) {
          const oldId = String(out[idx]?.sectorId ?? '');
          out[hit] = { ...out[hit], sectorId: oldId as any };
        }
      }

      out[idx] = next;
      return out;
    });
  }

  function freezeAsNewTemplate() {
    // 重要: ここで placements を slots として保存すると、未配置の slot が欠落した「1slotテンプレ」が作られます。
    // A案（0件スタートで1つずつ追加）では致命的なので、slots は「アクティブテンプレの slots を丸ごと複製」して保存します。
    // 盤面上の現在表示（placements/effectivePlacements）は、assigns（tile/rot）として保持する想定です。

    const baseTags: TemplateTags | null = activeTemplate ? { ...activeTemplate.tags } : null;
    const tags: TemplateTags = baseTags ?? { players: freezePlayers, expansion: freezeExp };
    const id = makeTemplateId(tags, freezeLabel);
    const ts = isoNow();

    const clonedSlots = (activeTemplate?.slots ?? []).map((s: any, i: number) => {
      const kind = (s?.kind ?? 'SECTOR') as any;
      const pos = s?.pos ?? s;
      return { kind, pos: { q: Number(pos?.q) || 0, r: Number(pos?.r) || 0 } };
    });

    const tpl: MapLayoutTemplate = {
      id,
      label: freezeLabel.trim() || 'Layout',
      tags,
      slots: clonedSlots.length > 0
        ? (clonedSlots as any)
        : (placements.map((p) => ({ kind: 'SECTOR', pos: { q: p.pos.q, r: p.pos.r } })) as any),
      createdAtIso: ts,
      updatedAtIso: ts,
    };

    const next = upsertTemplate(tpl);
    setTemplates(next);
    setActiveTemplateId(tpl.id);

    // assigns は「表示中のslotIndexにのみ存在」していて良いが、配列長は slots.length に合わせておく。
    setAssigns((prev) => {
      const out = [...prev];
      const n = tpl.slots.length;
      if (out.length < n) {
        for (let i = out.length; i < n; i++) out[i] = { sectorId: '', rot: 0 } as any;
      }
      return out.slWHITE(0, n);
    });

    // Freeze 直後も A案の思想に合わせて「表示行は現状維持」。
    // （すべて表示したい場合はここを slots.length 全表示に変えられる）
    setVisibleAssignSlotIndWHITEs((prev) => [...prev]);
    setRandomizeStatus("Freeze -> template created.");

    // 新テンプレに対して、現行の閾値を初期保存（明示）
    saveTemplateSettings(tpl.id, { balanceMaxL1, scoreThreshold });
  }

  function removeActiveTemplate() {
    if (!activeTemplate) return;
    const next = deleteTemplate(activeTemplate.id);
    setTemplates(next);
    setActiveTemplateId(next[0]?.id ?? "");
    setRandomizeStatus("");
  }

  const effectivePlacements = useMemo(() => {
    if (!activeTemplate) return placements;

    // A案: 未割当（sectorId==''）の slot は盤面生成対象から除外
    const out: SectorPlacement[] = [];
    for (let i = 0; i < activeTemplate.slots.length; i++) {
      const a = assigns[i];
      if (!a || !a.sectorId || String(a.sectorId).length === 0) continue;
      const s: any = activeTemplate.slots[i];
      const pos = s?.pos ?? s;
      const kind = (s?.kind ?? "SECTOR") as any;
      out.push({ sectorId: String(a.sectorId), rot: Number(a.rot) || 0, pos: { q: Number(pos.q), r: Number(pos.r) }, kind } as any);
    }
    return out;
  }, [activeTemplate, assigns, placements]);

  const logicPlacements = useMemo(() => {
    // 拡張テンプレ初期化や既存LS汚染で pos が NaN になると、board 構築で衝突（NaN,NaN）します。
    // Slot position editor で後から正しい座標へ置き直す前提なので、ここで「編集可能なステージング座標」に退避します。
    const STAGING_STEP_Q = 18;

    return effectivePlacements.map((p, i) => {
      const sectorId = normalizeSectorIdForLogic(p.sectorId);

      const qRaw: unknown = (p as any).pos?.q;
      const rRaw: unknown = (p as any).pos?.r;
      const q = typeof qRaw === "number" ? qRaw : typeof qRaw === "string" ? Number(qRaw) : NaN;
      const r = typeof rRaw === "number" ? rRaw : typeof rRaw === "string" ? Number(rRaw) : NaN;

      if (!Number.isFinite(q) || !Number.isFinite(r)) {
        return { ...p, sectorId, pos: { q: i * STAGING_STEP_Q, r: 0 } } as any;
      }
      return { ...p, sectorId, pos: { q, r } } as any;
    });
  }, [effectivePlacements]);

  const size = 28;
  const padding = 60;

  const { board, buildError } = useMemo(() => {
    try {
      const b = buildLogicBoardWithLocalColumnShift(SECTORS_WITH_TILE_TAG, logicPlacements, {
        viewRot60: VIEW_ROT60,
        viewMirror: VIEW_MIRROR,
        orientationForColumnOrder: "flat",
        sizeForColumnOrder: 28,
        rule: RULE,
      });
      return { board: b, buildError: "" };
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      return { board: { cells: new Map<string, Cell>() }, buildError: msg };
    }
  }, [effectivePlacements]);

  const violations = useMemo(() => {
    if (board.cells.size === 0) return [];
    return findForbiddenProximityPairs(board.cells, 2);
  }, [board]);

  const draftScoreMap = useMemo(() => {
    if (!activeTemplate) return null;
    return draftScoreByTemplate[activeTemplate.id] ?? null;
  }, [draftScoreByTemplate, activeTemplate]);

  const baseCellScoreMap = useMemo(() => {
    if (!activeTemplate) return null;
    return SCORE_MAPS_BY_TEMPLATE[activeTemplate.id] ?? null;
  }, [activeTemplate]);

  const effectiveCellScoreMap = useMemo(() => {
    if (draftScoreMap && Object.keys(draftScoreMap).length > 0) return draftScoreMap;
    return baseCellScoreMap;
  }, [draftScoreMap, baseCellScoreMap]);

  // Scoring (absolute scoreMap + SWAMP proximity bonus)
  const scoreResult = useMemo(() => {
    if (board.cells.size === 0) return null as any;
    const cellScoreMap = (effectiveCellScoreMap as DraftScoreMap | null) ?? null;
    return computeScoreAndBalance(board.cells, cellScoreMap, {
      enableSwampDist2,
      enableSwampDist1Extra,
      neighborScoreMode,
      TRANSDIMNeighborMode,
      neighborRequireNonNegativeCellScore,
      neighborWCount,
      neighborWType,
    });
  }, [board, effectiveCellScoreMap, enableSwampDist2, enableSwampDist1Extra, neighborScoreMode, TRANSDIMNeighborMode, neighborRequireNonNegativeCellScore, neighborWCount, neighborWType]);

  const currentTotal = useMemo(() => {
    if (!scoreResult) return 0;
    return typeof (scoreResult as any).grandTotal === "number" ? (scoreResult as any).grandTotal : 0;
  }, [scoreResult]);

  // PlanetType 表示（和訳＋色表示）
  const PLANET_TYPE_JA: Record<PlanetType, string> = {
    YELLOW: "黄",
    BLUE: "青",
    WHITE: "白",
    BROWN: "茶",
    TRANSDIM: "黒",
    ORANGE: "橙",
    RED: "赤",
    TRANSDIM: "TRANSDIM",
    SWAMP: "SWAMP",
    EMPTY: "EMPTY",
  };

  // PlanetType 表示部分のみ背景色を付与（黒だけ文字色は白）
  const PLANET_TYPE_BG: Partial<Record<PlanetType, string>> = {
    YELLOW: "#f1c40f",
    BLUE: "#3498db",
    WHITE: "#ecf0f1",
    BROWN: "#8e5a2b",
    TRANSDIM: "#111111",
    ORANGE: "#e67e22",
    RED: "#e74c3c",
  };

  const planetTypeBadgeStyle = (pt: PlanetType): React.CSSProperties => {
    const bg = PLANET_TYPE_BG[pt];
    if (!bg) return { fontWeight: 800 };
    const fg = pt === "TRANSDIM" ? "#ffffff" : "#000000";
    return {
      fontWeight: 800,
      background: bg,
      color: fg,
      padding: "2px 6px",
      borderRadius: 6,
      display: "inline-block",
      lineHeight: 1.4,
    };
  };

  const scoreAuditRows = useMemo(() => {
    if (!scoreResult) return [];
    const s: any = scoreResult;
    const rows = SCORE_TYPES.map((pt) => {
      const baseByTile: Record<string, number> = s.baseByTileByType?.[pt] ?? {};
      const swampTiles: string[] = s.swampTilesByType?.[pt] ?? [];
      const baseSum = Object.values(baseByTile).reduce((a, b) => a + b, 0);
      const swampSum = s.swampBonusByType?.[pt] ?? 0;
      const neighborSum = s.neighborSumByType?.[pt] ?? 0;
      const total = s.totalByType?.[pt] ?? (baseSum + swampSum + neighborSum);

      // Compact string for table column (non-zero only)
      const baseTilesStr = Object.entries(baseByTile)
        .sort((a, b) => a[0].localeCompare(b[0]))
        .map(([tid, v]) => `${tid}:${v > 0 ? `+${v}` : v}`)
        .join(", ");

      const swampTilesStr = swampTiles.join(", ");

      return { pt, baseSum, swampSum, neighborSum, total, baseByTile, swampTiles, baseTilesStr, swampTilesStr };
    });

    // Sort: Total desc, Neighbor desc, SWAMP desc, PlanetType desc
    rows.sort((a, b) => {
      if (b.total !== a.total) return b.total - a.total;
      if (b.neighborSum !== a.neighborSum) return b.neighborSum - a.neighborSum;
      if (b.swampSum !== a.swampSum) return b.swampSum - a.swampSum;
      return b.pt.localeCompare(a.pt);
    });

    return rows;
  }, [scoreResult]);

  const keys = useMemo(() => Array.from(board.cells.keys()).sort(), [board]);
  const currentBalanceL1 = useMemo(() => {
    if (!scoreResult) return null as number | null;
    const s: any = scoreResult as any;
    return typeof s.balanceL1 === "number" ? s.balanceL1 : null;
  }, [scoreResult]);
  // Rendering uses logic-accurate board/cells; Middle image-only adjustments are applied only in tile drawing.
  const renderKeys = keys;


  const bounds = useMemo(() => {
    // Cell bounds (for debug/click grid)
    let cellMinX = Infinity,
      cellMinY = Infinity,
      cellMaxX = -Infinity,
      cellMaxY = -Infinity;

    if (keys.length > 0) {
      for (const k of keys) {
        const a = parseKey(k);
        if (!Number.isFinite((a as any)?.q) || !Number.isFinite((a as any)?.r)) return;
        const { x, y } = axialToPixel(a, size, ORIENTATION);
        cellMinX = Math.min(cellMinX, x - size);
        cellMinY = Math.min(cellMinY, y - size);
        cellMaxX = Math.max(cellMaxX, x + size);
        cellMaxY = Math.max(cellMaxY, y + size);
      }
    } else {
      cellMinX = cellMinY = cellMaxX = cellMaxY = 0;
    }

    // Tile-image bounds (tiles are larger than per-cell extents)
    let tileMinX = Infinity,
      tileMinY = Infinity,
      tileMaxX = -Infinity,
      tileMaxY = -Infinity;

    if (logicPlacements.length > 0) {
      for (const p of logicPlacements) {
        const isMiddle = (p as any)?.kind === "MIDDLE";
        const factor = isMiddle ? middleTileImgFactor : SECTOR_TILE_IMG_FACTOR;
        const imgHalf = (size * factor) / 2;
        const viewPos = rotate60(p.pos, (tileMapRot60 + 600) % 6);
        const { x, y } = axialToPixel(viewPos, size, ORIENTATION);
        const rotBase = rot6((p as any).rot);
        const rotForDraw = isMiddle ? (rotBase + MIDDLE_DRAW_ROT_OFFSET) % 6 : rotBase;
        const off = isMiddle ? (MIDDLE_TILE_OFFSETS[rotForDraw] ?? { x: 0, y: 0 }) : { x: 0, y: 0 };
        const xx = x + off.x;
                const yy = y + off.y;
tileMinX = Math.min(tileMinX, xx - imgHalf);
        tileMinY = Math.min(tileMinY, yy - imgHalf);
        tileMaxX = Math.max(tileMaxX, xx + imgHalf);
        tileMaxY = Math.max(tileMaxY, yy + imgHalf);
      }
    } else {
      tileMinX = tileMinY = tileMaxX = tileMaxY = 0;
    }

    // Union (keeps scale/centering consistent between cells/tiles modes)
    const minX = Math.min(cellMinX, tileMinX);
    const minY = Math.min(cellMinY, tileMinY);
    const maxX = Math.max(cellMaxX, tileMaxX);
    const maxY = Math.max(cellMaxY, tileMaxY);
    if (!Number.isFinite(minX) || !Number.isFinite(minY) || !Number.isFinite(maxX) || !Number.isFinite(maxY)) {
      // Fallback: safe viewport around origin
      return { minX: -400, minY: -300, maxX: 400, maxY: 300 };
    }
    return { minX, minY, maxX, maxY };
  }, [keys, size, logicPlacements, tileMapRot60, middleTileImgFactor, middleTileOffsetX, middleTileOffsetY]);

  const vb = useMemo(() => {
    const w = bounds.maxX - bounds.minX + padding * 2;
    const h = bounds.maxY - bounds.minY + padding * 2;
    const x = bounds.minX - padding;
    const y = bounds.minY - padding;
    return { x, y, w, h };
  }, [bounds]);

  const safeVb = useMemo(() => {
    const x = Number.isFinite((vb as any)?.x) ? (vb as any).x : 0;
    const y = Number.isFinite((vb as any)?.y) ? (vb as any).y : 0;
    const w = Number.isFinite((vb as any)?.w) && (vb as any).w > 0 ? (vb as any).w : 1000;
    const h = Number.isFinite((vb as any)?.h) && (vb as any).h > 0 ? (vb as any).h : 800;
    return { x, y, w, h };
  }, [vb]);


  // --- Board-based viewBox (covers entire logical board regardless of placements) ---
  const boardVb = React.useMemo(() => {
    try {
      const entries = Array.from((board as any)?.cells ?? []);
      if (!entries || entries.length === 0) {
        return { x: -500, y: -500, w: 1000, h: 1000 };
      }
      let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      for (const [k] of entries) {
        const parts = String(k).split(",");
        const q = Number(parts[0]);
        const r = Number(parts[1]);
        if (!Number.isFinite(q) || !Number.isFinite(r)) continue;
        const pt = axialToPixel({ q, r }, size, ORIENTATION);
        if (pt.x < minX) minX = pt.x;
        if (pt.y < minY) minY = pt.y;
        if (pt.x > maxX) maxX = pt.x;
        if (pt.y > maxY) maxY = pt.y;
      }
      if (!Number.isFinite(minX) || !Number.isFinite(minY) || !Number.isFinite(maxX) || !Number.isFinite(maxY)) {
        return { x: -500, y: -500, w: 1000, h: 1000 };
      }
      const pad = size * 3;
      return { x: minX - pad, y: minY - pad, w: (maxX - minX) + pad * 2, h: (maxY - minY) + pad * 2 };
    } catch {
      return { x: -500, y: -500, w: 1000, h: 1000 };
    }
  }, [board, size]);


  // ---------------------------
  // Randomize（前版のまま：ここは省略せず保持）
  // ---------------------------
  function tryBuildWithAssigns(
    tpl: MapLayoutTemplate,
    cand: SlotAssignment[],
    threshold: number,
    cellScoreMap: DraftScoreMap | null,
    balanceMax: number
  ): Omit<TryResult, "attemptsUsed"> {
    try {
      const eff = placementsFromTemplate(tpl, cand);
      const effLogic = eff.map((p) => ({ ...p, sectorId: normalizeSectorIdForLogic(p.sectorId) }));

      const b = buildLogicBoardWithLocalColumnShift(SECTORS_WITH_TILE_TAG, effLogic, {
        viewRot60: VIEW_ROT60,
        viewMirror: VIEW_MIRROR,
        orientationForColumnOrder: "flat",
        sizeForColumnOrder: 28,
        rule: RULE,
      });

      const v = findForbiddenProximityPairs(b.cells, 2);
      if (v.length > 0) {
        const top = v[0];
        return { ok: false, reason: `Constraint violation: ${top.tag} ${top.aKey}↔${top.bKey} (d=${top.dist})` };
      }

      const s: any = computeScoreAndBalance(b.cells, cellScoreMap ?? null, {
        enableSwampDist2,
        enableSwampDist1Extra,
        neighborScoreMode,
        TRANSDIMNeighborMode,
        neighborRequireNonNegativeCellScore,
        neighborWCount,
        neighborWType,
      });
      const total = typeof s.grandTotal === "number" ? s.grandTotal : 0;

      // total threshold (existing)
      if (total > threshold) {
        return { ok: false, reason: `Score rejected: total=${total} > threshold=${threshold}`, scoreTotal: total };
      }

      // balance threshold
      const l1: number = typeof s.balanceL1 === "number" ? s.balanceL1 : 0;

      if (l1 > balanceMax) {
        return { ok: false, reason: `Balance rejected: L1=${l1.toFixed(3)} > max=${balanceMax}`, scoreTotal: total, balanceL1: l1 };
      }

      // planetScores: the per-PlanetType totals used as inputs to balanceL1
      const planetScores = Object.fromEntries(
        SCORE_TYPES.map((t) => [t, (s.totalByType?.[t] ?? 0) as number])
      ) as Record<PlanetType, number>;

      return { ok: true, assigns: cand, scoreTotal: total, balanceL1: l1, planetScores };

    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      return { ok: false, reason: msg };
    }
  }

  function makeRandomNoDupAssignsFromPool(pool: readonly string[], slotCount: number): SlotAssignment[] {
    if (pool.length < slotCount) throw new Error(`Not enough sector ids. sectorIds=${pool.length}, slots=${slotCount}`);
    const picked = shuffle(pool).slWHITE(0, slotCount);
    return picked.map((id) => ({ sectorId: id, rot: randInt(0, 5) }));
  }

  function toPersistedAssigns(a: SlotAssignment[]): PersistedAssigns {
    const out: PersistedAssigns = {};
    for (let i = 0; i < a.length; i++) {
      const slotKey = String(i);
      const tileId = a[i]?.sectorId ?? "";
      const rot = (a[i]?.rot ?? 0) as any;
      out[slotKey] = { tileId, rot };
    }
    return out;
  }

  function pushHistory(
    assignsOk: SlotAssignment[],
    attemptsUsed: number,
    scoreTotal: number,
    balanceL1: number | undefined,
    planetScores: Record<PlanetType, number>
  ) {
    // UI-only recent history (not persisted)
    const id = `${Date.now()}-${Math.random().toString(16).slWHITE(2)}`;
    const item: HistoryItem = { id, atIso: isoNow(), attemptsUsed, scoreTotal, balanceL1, assigns: assignsOk };
    setHistory((prev) => [item, ...prev].slWHITE(0, HISTORY_MAX));

    // Persisted history (SSOT)
    try {
      appendHistoryEntry({
        templateId: activeTemplateId,
        dispersionValue: typeof balanceL1 === "number" ? balanceL1 : 0,
        planetScores,
        used: false,
        assigns: toPersistedAssigns(assignsOk),
        TRANSDIMNeighborMode,
      });
    } catch {
      // ignore persistence failure (do not break search loop)
    }
  }

  function applyHistory(item: HistoryItem) {
    setAssigns(item.assigns);
    setRandomizeStatus(
      `Applied history: ${shortIso(item.atIso)} (attempts=${item.attemptsUsed}, total=${item.scoreTotal}${
        typeof item.balanceL1 === "number" ? `, L1=${item.balanceL1.toFixed(3)}` : ""
      })`
    );
  }

  function deleteHistory(id: string) {
    setHistory((prev) => prev.filter((x) => x.id !== id));
  }

  function clearHistory() {
    setHistory([]);
    setRandomizeStatus("History cleared.");
  }

  function stopSearch() {
    stopSearchRef.current = true;
    setRandomizeStatus((prev) => (prev ? prev + " (stopping…)" : "Stopping…"));
  }

  async function yieldToUi() {
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
  }

  function randomizeNoDupAndValidate() {
    if (!activeTemplate) {
      setRandomizeStatus("No active template.");
      return;
    }
    if (isSearching) return;

    stopSearchRef.current = false;
    setIsSearching(true);
    setLastAttempts(0);
    setSearchElapsedMs(0);
    setSearchSpeed(0);
    setLastRejectReason("");
    setRandomizeStatus("Searching…");

    const slotCount = activeTemplate.slots.length;
    const pool = getSectorPoolForTemplate(activeTemplate);
    const cellScoreMap = effectiveCellScoreMap as DraftScoreMap | null;

    const start = performance.now();
    let lastUiUpdate = start;

    (async () => {
      for (let attempt = 1; ; attempt++) {
        if (stopSearchRef.current) {
          setIsSearching(false);
          setLastAttempts(attempt - 1);
          setRandomizeStatus(`Stopped. attempts=${attempt - 1}`);
          return;
        }
        if (maxAttempts > 0 && attempt > maxAttempts) {
          setIsSearching(false);
          setLastAttempts(maxAttempts);
          setRandomizeStatus(`Search failed (no solution in ${maxAttempts}). Last reason: ${lastRejectReason || "(none)"}`);
          return;
        }

        let cand: SlotAssignment[];
        try {
          cand = makeRandomNoDupAssignsFromPool(pool, slotCount);

          // 3P slot constraint (fast pre-check, avoids heavy build)
          if (activeTemplate?.tags?.players === 3) {
            const sc = check3pSlotConstraint(slotConstraint3p, cand);
            if (!sc.ok) {
              setLastRejectReason(sc.reason);
              // periodic UI update
              if (attempt % 200 === 0) {
                const now = performance.now();
                const elapsed = now - start;
                setLastAttempts(attempt);
                setSearchElapsedMs(elapsed);
                setSearchSpeed(elapsed > 0 ? (attempt / elapsed) * 1000 : 0);
                if (now - lastUiUpdate > 250) {
                  setRandomizeStatus(`Searching… attempts=${attempt} (${((attempt / elapsed) * 1000).toFixed(0)}/s)`);
                  lastUiUpdate = now;
                }
                await yieldToUi();
              }
              continue;
            }
          }
        } catch (e) {
          const msg = e instanceof Error ? e.message : String(e);
          setIsSearching(false);
          setRandomizeStatus(`Randomize failed: ${msg}`);
          return;
        }

        const res = tryBuildWithAssigns(activeTemplate, cand, scoreThreshold, cellScoreMap, balanceMaxL1);
        if (res.ok) {
          const now = performance.now();
          const elapsed = now - start;

          // Always show the latest found map
          setAssigns(res.assigns);
          setLastAttempts(attempt);
          setSearchElapsedMs(elapsed);
          setSearchSpeed(elapsed > 0 ? (attempt / elapsed) * 1000 : 0);

          if (searchMode === "single") {
            setIsSearching(false);
            setRandomizeStatus(
              `Found! attempts=${attempt} (${(elapsed / 1000).toFixed(2)}s, ${((attempt / elapsed) * 1000).toFixed(
                0
              )}/s) total=${res.scoreTotal}${typeof res.balanceL1 === "number" ? ` L1=${res.balanceL1.toFixed(3)}` : ""}`
            );
            pushHistory(res.assigns, attempt, res.scoreTotal, res.balanceL1, res.planetScores);
            return;
          } else {
            setRandomizeStatus(
              `Found (continuing)… attempts=${attempt} (${(elapsed / 1000).toFixed(2)}s, ${((attempt / elapsed) * 1000).toFixed(
                0
              )}/s) total=${res.scoreTotal}${typeof res.balanceL1 === "number" ? ` L1=${res.balanceL1.toFixed(3)}` : ""}`
            );
            pushHistory(res.assigns, attempt, res.scoreTotal, res.balanceL1, res.planetScores);
            // keep searching until stopped
            await yieldToUi();
          }
        } else {
          setLastRejectReason(res.reason);
        }

        // periodic UI update + yield
        if (attempt % 200 === 0) {
          const now = performance.now();
          const elapsed = now - start;
          setLastAttempts(attempt);
          setSearchElapsedMs(elapsed);
          setSearchSpeed(elapsed > 0 ? (attempt / elapsed) * 1000 : 0);
          if (now - lastUiUpdate > 250) {
            setRandomizeStatus(`Searching… attempts=${attempt} (${((attempt / elapsed) * 1000).toFixed(0)}/s)`);
            lastUiUpdate = now;
          }
          await yieldToUi();
        }
      }
    })().catch((e) => {
      const msg = e instanceof Error ? e.message : String(e);
      setIsSearching(false);
      setRandomizeStatus(`Search error: ${msg}`);
    });
  }

  function randomizeRotOnlyAndValidate() {
    if (!activeTemplate) {
      setRandomizeStatus("No active template.");
      return;
    }
    if (isSearching) return;

    stopSearchRef.current = false;
    setIsSearching(true);
    setLastAttempts(0);
    setSearchElapsedMs(0);
    setSearchSpeed(0);
    setLastRejectReason("");
    setRandomizeStatus("Searching (rot only)…");

    const slotCount = activeTemplate.slots.length;
    const pool = getSectorPoolForTemplate(activeTemplate);
    const baseIds = assigns
      .slWHITE(0, slotCount)
      .map((a, i) => (a?.sectorId ?? defaultAssignFromPool(i, pool).sectorId) as SectorId);

    // 3P slot constraint pre-check: sector ids are fixed in rot-only mode
    if (activeTemplate?.tags?.players === 3) {
      const dummyCand: SlotAssignment[] = baseIds.map((id) => ({ sectorId: id, rot: 0 }));
      const sc = check3pSlotConstraint(slotConstraint3p, dummyCand);
      if (!sc.ok) {
        setIsSearching(false);
        setRandomizeStatus(sc.reason);
        setLastAttempts(0);
        return;
      }
    }

    const cellScoreMap = effectiveCellScoreMap as DraftScoreMap | null;
    const start = performance.now();
    let lastUiUpdate = start;

    (async () => {
      for (let attempt = 1; ; attempt++) {
        if (stopSearchRef.current) {
          setIsSearching(false);
          setLastAttempts(attempt - 1);
          setRandomizeStatus(`Stopped. attempts=${attempt - 1}`);
          return;
        }
        if (maxAttempts > 0 && attempt > maxAttempts) {
          setIsSearching(false);
          setLastAttempts(maxAttempts);
          setRandomizeStatus(`Search failed (no solution in ${maxAttempts}). Last reason: ${lastRejectReason || "(none)"}`);
          return;
        }

        const cand: SlotAssignment[] = baseIds.map((id) => ({ sectorId: id, rot: randInt(0, 5) }));
        const res = tryBuildWithAssigns(activeTemplate, cand, scoreThreshold, cellScoreMap, balanceMaxL1);

        if (res.ok) {
          const now = performance.now();
          const elapsed = now - start;

          // Always show the latest found map
          setAssigns(res.assigns);
          setLastAttempts(attempt);
          setSearchElapsedMs(elapsed);
          setSearchSpeed(elapsed > 0 ? (attempt / elapsed) * 1000 : 0);

          if (searchMode === "single") {
            setIsSearching(false);
            setRandomizeStatus(
              `Found! (rot only) attempts=${attempt} (${(elapsed / 1000).toFixed(2)}s, ${((attempt / elapsed) * 1000).toFixed(
                0
              )}/s) total=${res.scoreTotal}${typeof res.balanceL1 === "number" ? ` L1=${res.balanceL1.toFixed(3)}` : ""}`
            );
            pushHistory(res.assigns, attempt, res.scoreTotal, res.balanceL1, res.planetScores);
            return;
          } else {
            setRandomizeStatus(
              `Found (rot only, continuing)… attempts=${attempt} (${(elapsed / 1000).toFixed(2)}s, ${((attempt / elapsed) * 1000).toFixed(
                0
              )}/s) total=${res.scoreTotal}${typeof res.balanceL1 === "number" ? ` L1=${res.balanceL1.toFixed(3)}` : ""}`
            );
            pushHistory(res.assigns, attempt, res.scoreTotal, res.balanceL1, res.planetScores);
            await yieldToUi();
          }
        } else {
          setLastRejectReason(res.reason);
        }

        if (attempt % 200 === 0) {
          const now = performance.now();
          const elapsed = now - start;
          setLastAttempts(attempt);
          setSearchElapsedMs(elapsed);
          setSearchSpeed(elapsed > 0 ? (attempt / elapsed) * 1000 : 0);
          if (now - lastUiUpdate > 250) {
            setRandomizeStatus(`Searching (rot only)… attempts=${attempt} (${((attempt / elapsed) * 1000).toFixed(0)}/s)`);
            lastUiUpdate = now;
          }
          await yieldToUi();
        }
      }
    })().catch((e) => {
      const msg = e instanceof Error ? e.message : String(e);
      setIsSearching(false);
      setRandomizeStatus(`Search error: ${msg}`);
    });
  }

  // ---------------------------
  // Pick（クリック取得 -> 一括反映）
  // ---------------------------
  function togglePickedKey(k: string) {
    setPickedKeys((prev) => {
      const next = new Set(prev);
      if (next.has(k)) next.delete(k);
      else next.add(k);
      return next;
    });
  }

  function clearPicked() {
    setPickedKeys(new Set());
    setPickStatus("Selection cleared.");
  }

  function applyPickToDraft() {
    if (!activeTemplate) {
      setPickStatus("No active template.");
      return;
    }
    if (pickedKeys.size === 0) {
      setPickStatus("No cells selected.");
      return;
    }

    const tplId = activeTemplate.id;

    setDraftScoreByTemplate((prev) => {
      const cur = prev[tplId] ?? {};
      const next: DraftScoreMap = { ...cur };
      for (const k of pickedKeys) next[k] = pickValue;
      return { ...prev, [tplId]: next };
    });

    setPickStatus(`Applied score=${pickValue} to ${pickedKeys.size} cells.`);
    setPickedKeys(new Set());
  }

  function removeDraftKey(k: string) {
    if (!activeTemplate) return;
    const tplId = activeTemplate.id;

    setDraftScoreByTemplate((prev) => {
      const cur = prev[tplId] ?? {};
      if (!(k in cur)) return prev;
      const next: DraftScoreMap = { ...cur };
      delete next[k];
      return { ...prev, [tplId]: next };
    });
  }

  function clearDraft() {
    if (!activeTemplate) return;
    const tplId = activeTemplate.id;
    setDraftScoreByTemplate((prev) => ({ ...prev, [tplId]: {} }));
    setPickStatus("Draft score map cleared.");
  }

  // IMPORTANT:
  // scoreMaps.ts へ貼るのは「代入文」ではなく「オブジェクトのエントリ」にする（Next/Turbopackのパース事故を回避）
  function exportDraftSnippet(): string {
    if (!activeTemplate) return "";
    const tplId = activeTemplate.id;
    const m = draftScoreByTemplate[tplId] ?? {};
    const body = JSON.stringify(m, null, 2);
    return `// templateId: ${tplId}\n"${tplId}": ${body},\n`;
  }

  async function copyDraftSnippet() {
    const text = exportDraftSnippet();
    if (!text) {
      setPickStatus("Nothing to copy.");
      return;
    }
    try {
      await navigator.clipboard.writeText(text);
      setPickStatus("Copied snippet to clipboard.");
    } catch {
      setPickStatus("Copy failed (clipboard not available).");
    }
  }

  const draftEntriesSorted = useMemo(() => {
    if (!activeTemplate) return [];
    const m = draftScoreMap ?? {};
    return Object.entries(m)
      .map(([k, v]) => ({ k, v }))
      .sort((a, b) => {
        if (b.v !== a.v) return b.v - a.v;
        return a.k.localeCompare(b.k);
      });
  }, [activeTemplate, draftScoreMap]);

  return (
    <div style={{ display: "grid", gridTemplateColumns: "460px 1fr", gap: 16, padding: 16 }}>
      {/* Left */}
      <div style={{ border: "1px solid #ddd", borderRadius: 10, padding: 12, overflowX: "hidden", maxWidth: "100%", minWidth: 0 }}>
        <div style={{ fontWeight: 900, marginBottom: 10 }}>Map Templates</div>

        {/* Filters */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
          <label style={{ display: "grid", gap: 4 }}>
            players
            <select
              value={filterPlayers}
              onChange={(e) => setFilterPlayers(e.target.value === "all" ? "all" : (Number(e.target.value) as 3 | 4))}
              style={{ padding: 6, borderRadius: 8, border: "1px solid #ccc" }}
            >
              <option value="all">all</option>
              <option value="3">3</option>
              <option value="4">4</option>
            </select>
          </label>

          {/* Slot position editor (A方式) */}
          <div style={{ marginTop: 10, display: "grid", gap: 6, padding: 10, border: "1px solid #ddd", borderRadius: 10 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, justifyContent: "space-between" }}>
              <strong>Slot position editor</strong>
              <label style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <input
                  type="checkbox"
                  checked={slotEditMode === "editPos"}
                  onChange={(e) => {
                    setSlotEditMode(e.target.checked ? "editPos" : "none");
                    setEditingSlotIndex(null);
                  }}
                />
                enable
              </label>
            </div>

            <div style={{ display: "grid", gap: 6 }}>
              <div style={{ fontSize: 12, color: "#555" }}>
                手順: slotIndex を選択 → 盤面セルをクリック（pos を更新）
              </div>

              <select
                value={editingSlotIndex ?? ""}
                disabled={slotEditMode !== "editPos" || !activeTemplate}
                onChange={(e) => setEditingSlotIndex(e.target.value === "" ? null : Number(e.target.value))}
                style={{ padding: 6, borderRadius: 8, border: "1px solid #ccc" }}
              >
                <option value="">(select slotIndex)</option>
                {activeTemplate?.slots.map((s, i) => (
                  <option key={i} value={i}>
                    [{i}] {s.kind} / {assigns[i]?.sectorId ?? "-"} (q={s.pos.q},r={s.pos.r})
                  </option>
                ))}
              </select>

              {/* SMALL mode (Scout/Little) */}
              {activeTemplate?.tags?.expansion === "exp" && (
                <div style={{ display: "grid", gap: 6, paddingTop: 6 }}>
                  <div style={{ fontWeight: 600 }}>SMALL mode (Scout/Little)</div>
                  <div style={{ display: "grid", gap: 4 }}>
                    {(["free", "scoutFixedAll", "scoutFixedSome"] as const).map((m) => (
                      <label key={m} style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <input
                          type="radio"
                          name="smallMode"
                          checked={(activeTemplate.meta?.smallMode ?? "free") === m}
                          onChange={() => {
                            if (!activeTemplate) return;
                            const next: MapLayoutTemplate = {
                              ...activeTemplate,
                              meta: { ...(activeTemplate.meta ?? {}), smallMode: m, fixedScoutSlotIndWHITEs: activeTemplate.meta?.fixedScoutSlotIndWHITEs ?? [] },
                            };
                            const nextList = upsertTemplate(next);
                            setTemplates(nextList);
                            setActiveTemplateId(next.id);
                          }}
                        />
                        {m}
                      </label>
                    ))}
                  </div>

                  <details>
                    <summary style={{ cursor: "pointer" }}>fixed scout slots (slotIndex)</summary>
                    <div style={{ display: "grid", gap: 4, paddingTop: 6, maxHeight: 180, overflow: "auto" }}>
                      {activeTemplate.slots.map((s, i) => {
                        if (s.kind !== "SMALL") return null;
                        const fixed = new Set(activeTemplate.meta?.fixedScoutSlotIndWHITEs ?? []);
                        const checked = fixed.has(i);
                        return (
                          <label key={i} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12 }}>
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={() => {
                                if (!activeTemplate) return;
                                const cur = new Set(activeTemplate.meta?.fixedScoutSlotIndWHITEs ?? []);
                                if (cur.has(i)) cur.delete(i);
                                else cur.add(i);
                                const next: MapLayoutTemplate = {
                                  ...activeTemplate,
                                  meta: { ...(activeTemplate.meta ?? {}), fixedScoutSlotIndWHITEs: Array.from(cur).sort((a, b) => a - b) },
                                };
                                const nextList = upsertTemplate(next);
                                setTemplates(nextList);
                                setActiveTemplateId(next.id);
                              }}
                            />
                            [{i}] SMALL / {assigns[i]?.sectorId ?? "-"}
                          </label>
                        );
                      })}
                    </div>
                  </details>
                </div>
              )}

              {!assignValidation.ok && (
                <div style={{ padding: 10, borderRadius: 10, border: "1px solid #f2b8b8", background: "#fff5f5", color: "#b42318" }}>
                  <div style={{ fontWeight: 700, marginBottom: 6 }}>Assign rule violations</div>
                  <ul style={{ margin: 0, paddingLeft: 18 }}>
                    {assignValidation.errors.map((e: any, idx: number) => (
                      <li key={idx}>{e.message}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>


          <label style={{ display: "grid", gap: 4 }}>
            expansion
            <select
              value={filterExp}
              onChange={(e) => setFilterExp(e.target.value as any)}
              style={{ padding: 6, borderRadius: 8, border: "1px solid #ccc" }}
            >
              <option value="all">all</option>
              <option value="base">base</option>
              <option value="exp">exp</option>
            </select>
          </label>
        </div>

        {/* Template select */}
        <div style={{ marginTop: 10, display: "grid", gap: 6 }}>
          <label style={{ display: "grid", gap: 4 }}>
            active template
            <select
              value={activeTemplateId}
              onChange={(e) => {
                setActiveTemplateId(e.target.value);
                setRandomizeStatus("");
                setLastAttempts(0);
              }}
              style={{ padding: 6, borderRadius: 8, border: "1px solid #ccc" }}
            >
              <option value="">(none)</option>
              {filteredTemplates.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.label} [{t.tags.expansion}/{t.tags.players}p] ({t.slots.length})
                </option>
              ))}
            </select>
          </label>

          <div style={{ display: "flex", gap: 8 }}>
            <button
              onClick={removeActiveTemplate}
              disabled={!activeTemplate}
              style={{
                border: "1px solid #ccc",
                borderRadius: 10,
                padding: "8px 10px",
                background: "#fff",
                cursor: activeTemplate ? "pointer" : "not-allowed",
                opacity: activeTemplate ? 1 : 0.5,
                width: "100%",
              }}
            >
              Delete active template
            </button>

            <button
              onClick={() => saveTemplates(templates)}
              style={{
                border: "1px solid #ccc",
                borderRadius: 10,
                padding: "8px 10px",
                background: "#fff",
                cursor: "pointer",
                whiteSpace: "nowrap",
              }}
            >
              Save
            </button>
          </div>

          {/* Thresholds */}
          <div style={{ marginTop: 6, border: "1px solid #eee", borderRadius: 10, padding: 10 }}>
            <div style={{ fontWeight: 800, marginBottom: 6 }}>Thresholds</div>

            <label style={{ display: "grid", gap: 4 }}>
              scoreThreshold (reject if total score &gt; threshold)
              <input
                type="number"
                value={scoreThreshold}
                onChange={(e) => setScoreThreshold(Number(e.target.value))}
                style={{ padding: 6, borderRadius: 8, border: "1px solid #ccc" }}
              />
            </label>

            <label style={{ display: "grid", gap: 4, marginTop: 8 }}>
              balanceMaxL1 (reject if L1 &gt; max) — default 0.75
              <input
                type="number"
                step="0.01"
                value={balanceMaxL1}
                onChange={(e) => setBalanceMaxL1(Number(e.target.value))}
                style={{ padding: 6, borderRadius: 8, border: "1px solid #ccc" }}
              />
            </label>

            <div style={{ marginTop: 8, fontSize: 12, color: "#333" }}>
              current total score: <b>{currentTotal}</b> / threshold: <b>{scoreThreshold}</b>
              <br />
              current L1:{" "}
              <b>{typeof currentBalanceL1 === "number" ? currentBalanceL1.toFixed(3) : "(not available)"}</b> / max: <b>{balanceMaxL1}</b>
              <div style={{ color: "#666", marginTop: 6 }}>
                scoreMap:{" "}
                {activeTemplate
                  ? effectiveCellScoreMap
                    ? draftScoreMap && Object.keys(draftScoreMap).length > 0
                      ? "draft (click-picked) in use"
                      : "base (scoreMaps.ts) in use"
                    : "not defined (all 0)"
                  : "(no template)"}
              </div>
              <div style={{ color: "#666", marginTop: 6 }}>
                settings: template-scoped (auto-saved to localStorage)
              </div>
            </div>
          
          {/* Score Audit (by PlanetType) */}
          <div style={{ marginTop: 8, border: "1px solid #eee", borderRadius: 10, padding: 10 }}>
            <div style={{ fontWeight: 900, marginBottom: 6 }}>Score Audit (by PlanetType)</div>

            {!scoreResult ? (
              <div style={{ color: "#666", fontSize: 12 }}>No board (build error)</div>
            ) : (
              <>
                <div style={{ fontSize: 12, color: "#333", marginBottom: 8 }}>
                  grand total: <b>{currentTotal}</b> / balance(L1):{" "}
                  <b>{currentBalanceL1 !== null ? currentBalanceL1.toFixed(3) : "—"}</b>
                </div>

                <div style={{ overflowX: "auto", overflowY: "hidden", maxWidth: "100%", border: "1px solid #f0f0f0", borderRadius: 10 }}>
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12, tableLayout: "fixed" }}>
                    <thead>
                      <tr style={{ background: "#fafafa" }}>
                        <th style={{ textAlign: "left", padding: 8, borderBottom: "1px solid #eee" }}>色</th>
                        <th style={{ textAlign: "right", padding: 8, borderBottom: "1px solid #eee" }}>マップ</th>
                        <th style={{ textAlign: "right", padding: 8, borderBottom: "1px solid #eee" }}>緑</th>
                        <th style={{ textAlign: "right", padding: 8, borderBottom: "1px solid #eee" }}>近接</th>
                        <th style={{ textAlign: "right", padding: 8, borderBottom: "1px solid #eee" }}>合計</th>
</tr>
                    </thead>
                    <tbody>
                      {scoreAuditRows.map((r) => (
                        <tr
                          key={r.pt}
                          onClick={() => setAuditSelectedType(r.pt)}
                          style={{
                            cursor: "pointer",
                            background: auditSelectedType === r.pt ? "rgba(0,0,0,0.04)" : "transparent",
                          }}
                        >
                          <td style={{ textAlign: "left", padding: 8, borderBottom: "1px solid #eee" }}>
                            <span style={planetTypeBadgeStyle(r.pt)}>{PLANET_TYPE_JA[r.pt] ?? r.pt}</span>
                          </td>
                          <td style={{ textAlign: "right", padding: 8, borderBottom: "1px solid #eee" }}>{r.baseSum}</td>
                          <td style={{ textAlign: "right", padding: 8, borderBottom: "1px solid #eee" }}>{r.swampSum}</td>
                          <td style={{ textAlign: "right", padding: 8, borderBottom: "1px solid #eee" }}>{r.neighborSum}</td>
                          <td style={{ textAlign: "right", padding: 8, borderBottom: "1px solid #eee", fontWeight: 700 }}>{r.total}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Details */}
                {(() => {
                  const r = scoreAuditRows.find((x) => x.pt === auditSelectedType);
                  if (!r) return null;
                  const s: any = scoreResult;
                  const neighborByTile = (s.neighborByTileByType?.[r.pt] ?? {}) as Record<string, { n: number; types: Set<string>; points: number }>;
                  const neighborEntries = Object.entries(neighborByTile)
                    .map(([tid, v]) => ({ tid, n: v.n, u: typeof v.u === "number" ? v.u : (v.types ? Array.from(v.types).length : 0), types: v.types ? Array.from(v.types).sort() : [], points: v.points }))
                    .sort((a, b) => b.points - a.points || a.tid.localeCompare(b.tid));

                  return (
                    <div style={{ marginTop: 10, borderTop: "1px solid #eee", paddingTop: 10 }}>
                      <div style={{ fontWeight: 800, marginBottom: 6 }}>Details: {r.pt}</div>

                      <div style={{ display: "grid", gap: 10 }}>
                        <div>
                          <div style={{ fontWeight: 700, marginBottom: 4 }}>Base contributions (non-zero only)</div>
                          {Object.keys(r.baseByTile).length === 0 ? (
                            <div style={{ color: "#666", fontSize: 12 }}>—</div>
                          ) : (
                            <div style={{ display: "grid", gap: 4 }}>
                              {Object.entries(r.baseByTile)
                                .sort((a, b) => a[0].localeCompare(b[0]))
                                .map(([tid, v]) => (
                                  <div key={tid} style={{ fontFamily: "ui-monospace, Menlo, monospace", fontSize: 12 }}>
                                    Tile {tid}: {v > 0 ? `+${v}` : v}
                                  </div>
                                ))}
                            </div>
                          )}
                          <div style={{ marginTop: 4, fontSize: 12 }}>
                            Base sum: <b>{r.baseSum}</b>
                          </div>
                        </div>

                        <div>
                          <div style={{ fontWeight: 700, marginBottom: 4 }}>SWAMP bonus sources (tile ids)</div>
                          {r.swampTiles.length === 0 ? (
                            <div style={{ color: "#666", fontSize: 12 }}>—</div>
                          ) : (
                            <div style={{ fontFamily: "ui-monospace, Menlo, monospace", fontSize: 12 }}>{r.swampTiles.join(", ")}</div>
                          )}
                          <div style={{ marginTop: 4, fontSize: 12 }}>
                            SWAMP bonus sum: <b>{r.swampSum}</b>
                          </div>
                        </div>

                        <div>
                          <div style={{ fontWeight: 700, marginBottom: 4 }}>Neighbor score (anchor tile aggregated)</div>

                          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 8 }}>
                            <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12 }}>
                              <input
                                type="checkbox"
                                checked={enableSwampDist2}
                                onChange={(e) => setEnableSwampDist2(e.target.checked)}
                              />
                              SWAMP bonus (dist ≤ 2)
                            </label>

                            <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12 }}>
                              <input
                                type="checkbox"
                                checked={enableSwampDist1Extra}
                                onChange={(e) => setEnableSwampDist1Extra(e.target.checked)}
                                disabled={!enableSwampDist2}
                              />
                              extra +1 if dist ≤ 1
                            </label>
                          </div>
                          <div style={{ fontSize: 12, color: "#333", marginBottom: 6 }}>
                            mode: <b>{neighborScoreMode}</b> / TRANSDIM（近傍）: <b>{TRANSDIMNeighborMode}</b> / require cellScore&gt;=0:{" "}
                            <b>{String(neighborRequireNonNegativeCellScore)}</b> / weights: <b>{neighborWCount}/{neighborWType}</b>
                          </div>
                          <div style={{ marginTop: 6, display: "grid", gap: 6 }}>
                            <div style={{ fontSize: 12, fontWeight: 700 }}>TRANSDIM（近傍評価での扱い）</div>
                            <div style={{ display: "flex", gap: 14, flexWrap: "wrap", fontSize: 12 }}>
                              <label style={{ display: "flex", alignItems: "center", gap: 6 }}>
                                <input
                                  type="radio"
                                  name="TRANSDIMNeighborMode"
                                  checked={TRANSDIMNeighborMode === "same"}
                                  onChange={() => setTRANSDIMNeighborMode("same")}
                                />
                                通常カウント（1.0）
                              </label>
                              <label style={{ display: "flex", alignItems: "center", gap: 6 }}>
                                <input
                                  type="radio"
                                  name="TRANSDIMNeighborMode"
                                  checked={TRANSDIMNeighborMode === "half"}
                                  onChange={() => setTRANSDIMNeighborMode("half")}
                                />
                                0.5としてカウント
                              </label>
                              <label style={{ display: "flex", alignItems: "center", gap: 6 }}>
                                <input
                                  type="radio"
                                  name="TRANSDIMNeighborMode"
                                  checked={TRANSDIMNeighborMode === "off"}
                                  onChange={() => setTRANSDIMNeighborMode("off")}
                                />
                                カウントしない
                              </label>
                            </div>
                            <div style={{ fontSize: 11, color: "#666" }}>
                              「0.5」は N（数）と U（種類）の両方に適用します。SWAMPは常に除外です。
                            </div>
                          </div>


                          {neighborEntries.length === 0 ? (
                            <div style={{ color: "#666", fontSize: 12 }}>—</div>
                          ) : (
                            <div style={{ display: "grid", gap: 6 }}>
                              {neighborEntries.slWHITE(0, 50).map((e) => (
                                <div key={e.tid} style={{ border: "1px solid #f0f0f0", borderRadius: 10, padding: 8 }}>
                                  <div style={{ display: "flex", justifyContent: "space-between", gap: 8 }}>
                                    <div style={{ fontWeight: 700 }}>Anchor Tile {e.tid}</div>
                                    <div style={{ fontFamily: "ui-monospace, Menlo, monospace", fontSize: 12 }}>points={e.points}</div>
                                  </div>
                                  <div style={{ marginTop: 4, fontSize: 12 }}>
                                    N={e.n}, U={e.u}
                                  </div>
                                  <div style={{ marginTop: 4, fontFamily: "ui-monospace, Menlo, monospace", fontSize: 12 }}>
                                    types={"{"}{e.types.join(", ")}{"}"}
                                  </div>
                                </div>
                              ))}
                              {neighborEntries.length > 50 && <div style={{ fontSize: 12, color: "#666" }}>…and {neighborEntries.length - 50} more</div>}
                            </div>
                          )}

                          <div style={{ marginTop: 4, fontSize: 12 }}>
                            Neighbor sum: <b>{r.neighborSum}</b>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </>
            )}
          </div>
</div>

          {/* Randomize controls */}
          <div style={{ display: "grid", gap: 8, marginTop: 6 }}>
            <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
              <div style={{ fontSize: 12, opacity: 0.8 }}>Search mode:</div>
              <label style={{ display: "flex", gap: 6, alignItems: "center", cursor: isSearching ? "not-allowed" : "pointer", opacity: isSearching ? 0.5 : 1 }}>
                <input
                  type="radio"
                  name="searchMode"
                  disabled={isSearching || !assignValidation.ok}
                  checked={searchMode === "single"}
                  onChange={() => setSearchMode("single")}
                />
                Stop on first hit
              </label>
              <label style={{ display: "flex", gap: 6, alignItems: "center", cursor: isSearching ? "not-allowed" : "pointer", opacity: isSearching ? 0.5 : 1 }}>
                <input
                  type="radio"
                  name="searchMode"
                  disabled={isSearching || !assignValidation.ok}
                  checked={searchMode === "continuous"}
                  onChange={() => setSearchMode("continuous")}
                />
                Keep searching until Stop
              </label>
            </div>

            <div style={{ display: "flex", gap: 8 }}>
              <button
                onClick={randomizeNoDupAndValidate}
                disabled={!activeTemplate || isSearching || !assignValidation.ok}
                style={{
                  width: "100%",
                  border: "1px solid #111",
                  borderRadius: 10,
                  padding: "10px 12px",
                  background: "#fff",
                  cursor: activeTemplate && !isSearching ? "pointer" : "not-allowed",
                  opacity: activeTemplate && !isSearching ? 1 : 0.5,
                }}
              >
                Start search (no dup, validate)
              </button>

              <button
                onClick={stopSearch}
                disabled={!isSearching}
                style={{
                  border: "1px solid #ccc",
                  borderRadius: 10,
                  padding: "10px 12px",
                  background: "#fff",
                  cursor: isSearching ? "pointer" : "not-allowed",
                  opacity: isSearching ? 1 : 0.5,
                  whiteSpace: "nowrap",
                }}
              >
                Stop
              </button>
            </div>

            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <button
                onClick={randomizeRotOnlyAndValidate}
                disabled={!activeTemplate || isSearching || !assignValidation.ok}
                style={{
                  width: "100%",
                  border: "1px solid #ccc",
                  borderRadius: 10,
                  padding: "10px 12px",
                  background: "#fff",
                  cursor: activeTemplate && !isSearching ? "pointer" : "not-allowed",
                  opacity: activeTemplate && !isSearching ? 1 : 0.5,
                }}
              >
                Start search (rot only, validate)
              </button>

              <label style={{ fontSize: 12, display: "flex", alignItems: "center", gap: 6 }}>
                maxAttempts
                <input
                  type="number"
                  step={1000}
                  min={0}
                  value={maxAttempts}
                  onChange={(e) => setMaxAttempts(Math.max(0, Math.floor(Number(e.target.value))))}
                  style={{ width: 90, padding: "6px 8px", borderRadius: 8, border: "1px solid #ccc" }}
                  title="0 = infinite"
                />
              </label>
</div>

{activeTemplate?.tags?.players === 3 ? (
  <div style={{ marginTop: 8 }}>
    <label style={{ fontSize: 12, display: "flex", alignItems: "center", gap: 6 }}>
      3P Slot constraint
      <select
        value={slotConstraint3p}
        onChange={(e) => setSlotConstraint3p(e.target.value as SlotConstraint3pMode)}
        style={{ padding: "6px 8px", borderRadius: 8, border: "1px solid #ccc" }}
      >
        <option value="NONE">制約なし</option>
        <option value="ALL_147_IN_1_4">slot1/4/7 全て sector1–4</option>
        <option value="AT_LEAST2_147_IN_1_4">slot1/4/7 のうち少なくとも2つ sector1–4</option>
        <option value="SLOT4_AND_ONE_OF_1OR7_IN_1_4">slot4 は sector1–4 ＋ slot1/7 のどちらか1つ</option>
        <option value="SLOT4_MUST_IN_1_4">slot4 は必ず sector1–4</option>
      </select>
    </label>
    <div style={{ fontSize: 11, color: "#666", marginTop: 2 }}>
      sector1–4 = 01–04 / slot1,4,7 = 1-indexed (1,4,7)
    </div>
  </div>
) : null}

<div style={{ fontSize: 12, color: "#333", display: "grid", gap: 2 }}>
              <div>
                attempts (this session): <b>{lastAttempts}</b>
              </div>
              <div>
                elapsed: <b>{(searchElapsedMs / 1000).toFixed(2)}s</b> / speed: <b>{searchElapsedMs > 0 ? searchSpeed.toFixed(0) : 0}/s</b>
              </div>
              {lastRejectReason ? (
                <div style={{ color: "#666" }}>
                  last reject: <span style={{ fontFamily: "ui-monospace, Menlo, monospace" }}>{lastRejectReason}</span>
                </div>
              ) : null}
              <div style={{ color: "#666" }}>maxAttempts: {maxAttempts === 0 ? "∞" : maxAttempts}</div>
            </div>

            {randomizeStatus && (
              <div
                style={{
                  border: "1px solid #eee",
                  borderRadius: 10,
                  padding: 10,
                  color: "#333",
                  background: "#fafafa",
                  fontSize: 12,
                }}
              >
                {randomizeStatus}
              </div>
            )}
          </div>
{/* History */}
          <div style={{ marginTop: 8, border: "1px solid #eee", borderRadius: 10, padding: 10 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ fontWeight: 900 }}>History (success only)</div>
              <button
                onClick={clearHistory}
                disabled={history.length === 0}
                style={{
                  border: "1px solid #ccc",
                  borderRadius: 8,
                  padding: "6px 10px",
                  background: "#fff",
                  cursor: history.length ? "pointer" : "not-allowed",
                  opacity: history.length ? 1 : 0.5,
                }}
              >
                Clear
              </button>
            </div>

            {history.length === 0 ? (
              <div style={{ marginTop: 8, color: "#666", fontSize: 12 }}>No history yet.</div>
            ) : (
              <div style={{ marginTop: 8, display: "grid", gap: 8 }}>
                {history.map((h) => (
                  <div key={h.id} style={{ border: "1px solid #f0f0f0", borderRadius: 10, padding: 8 }}>
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                      <div style={{ fontWeight: 700, fontSize: 12 }}>{shortIso(h.atIso)}</div>
                      <div style={{ fontFamily: "ui-monospace, Menlo, monospace", fontSize: 12 }}>
                        attempts={h.attemptsUsed} total={h.scoreTotal}
                        {typeof h.balanceL1 === "number" ? ` L1=${h.balanceL1.toFixed(3)}` : ""}
                      </div>
                    </div>

                    <div style={{ marginTop: 6, display: "flex", gap: 8 }}>
                      <button
                        onClick={() => applyHistory(h)}
                        style={{
                          border: "1px solid #111",
                          borderRadius: 8,
                          padding: "6px 10px",
                          background: "#fff",
                          cursor: "pointer",
                          width: "100%",
                        }}
                      >
                        Apply
                      </button>
                      <button
                        onClick={() => deleteHistory(h.id)}
                        style={{
                          border: "1px solid #ccc",
                          borderRadius: 8,
                          padding: "6px 10px",
                          background: "#fff",
                          cursor: "pointer",
                        }}
                      >
                        Delete
                      </button>
                    </div>

                    <div style={{ marginTop: 6, fontSize: 12, color: "#666" }}>
                      {h.assigns.map((a, i) => `#${i + 1}:${a.sectorId}/r${a.rot}`).join("  ")}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Pick UI */}
          <div style={{ marginTop: 8, border: "1px solid #eee", borderRadius: 10, padding: 10 }}>
            <div style={{ fontWeight: 900, marginBottom: 6 }}>Pick cells for scoring (hover to see target)</div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              <label style={{ display: "grid", gap: 4 }}>
                score to apply
                <input
                  type="number"
                  value={pickValue}
                  onChange={(e) => setPickValue(Number(e.target.value))}
                  style={{ padding: 6, borderRadius: 8, border: "1px solid #ccc" }}
                />
              </label>

              <div style={{ display: "grid", gap: 6 }}>
                <div style={{ fontSize: 12, color: "#333" }}>
                  selected: <b>{pickedKeys.size}</b>
                </div>
                <div style={{ fontSize: 12, color: "#333" }}>
                  hover:{" "}
                  <b style={{ fontFamily: "ui-monospace, Menlo, monospace" }}>
                    {hoverKey || "(none)"}
                  </b>
                </div>

                <div style={{ display: "flex", gap: 6 }}>
                  <button
                    onClick={applyPickToDraft}
                    disabled={!activeTemplate || pickedKeys.size === 0}
                    style={{
                      border: "1px solid #111",
                      borderRadius: 8,
                      padding: "6px 10px",
                      background: "#fff",
                      cursor: activeTemplate && pickedKeys.size ? "pointer" : "not-allowed",
                      opacity: activeTemplate && pickedKeys.size ? 1 : 0.5,
                      width: "100%",
                    }}
                  >
                    Apply to draft
                  </button>
                  <button
                    onClick={clearPicked}
                    disabled={pickedKeys.size === 0}
                    style={{
                      border: "1px solid #ccc",
                      borderRadius: 8,
                      padding: "6px 10px",
                      background: "#fff",
                      cursor: pickedKeys.size ? "pointer" : "not-allowed",
                      opacity: pickedKeys.size ? 1 : 0.5,
                      whiteSpace: "nowrap",
                    }}
                  >
                    Clear
                  </button>
                </div>
              </div>
            </div>

            <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
              <button
                onClick={() => setPickValue(2)}
                style={{ border: "1px solid #ccc", borderRadius: 999, padding: "6px 10px", background: "#fff", cursor: "pointer" }}
              >
                +2
              </button>
              <button
                onClick={() => setPickValue(1)}
                style={{ border: "1px solid #ccc", borderRadius: 999, padding: "6px 10px", background: "#fff", cursor: "pointer" }}
              >
                +1
              </button>
              <button
                onClick={() => setPickValue(-1)}
                style={{ border: "1px solid #ccc", borderRadius: 999, padding: "6px 10px", background: "#fff", cursor: "pointer" }}
              >
                -1
              </button>
              <button
                onClick={() => setPickValue(-2)}
                style={{ border: "1px solid #ccc", borderRadius: 999, padding: "6px 10px", background: "#fff", cursor: "pointer" }}
              >
                -2
              </button>
            </div>

            <div style={{ marginTop: 10, display: "flex", gap: 8 }}>
              <button
                onClick={copyDraftSnippet}
                disabled={!activeTemplate || !draftScoreMap || Object.keys(draftScoreMap).length === 0}
                style={{
                  border: "1px solid #111",
                  borderRadius: 10,
                  padding: "8px 10px",
                  background: "#fff",
                  cursor: activeTemplate && draftScoreMap && Object.keys(draftScoreMap).length ? "pointer" : "not-allowed",
                  opacity: activeTemplate && draftScoreMap && Object.keys(draftScoreMap).length ? 1 : 0.5,
                  width: "100%",
                }}
              >
                Copy snippet for scoreMaps.ts
              </button>

              <button
                onClick={clearDraft}
                disabled={!activeTemplate || !draftScoreMap || Object.keys(draftScoreMap).length === 0}
                style={{
                  border: "1px solid #ccc",
                  borderRadius: 10,
                  padding: "8px 10px",
                  background: "#fff",
                  cursor: activeTemplate && draftScoreMap && Object.keys(draftScoreMap).length ? "pointer" : "not-allowed",
                  opacity: activeTemplate && draftScoreMap && Object.keys(draftScoreMap).length ? 1 : 0.5,
                  whiteSpace: "nowrap",
                }}
              >
                Clear draft
              </button>
            </div>

            {pickStatus && (
              <div style={{ marginTop: 8, fontSize: 12, color: "#333", border: "1px solid #f0f0f0", borderRadius: 10, padding: 8, background: "#fafafa" }}>
                {pickStatus}
              </div>
            )}

            <div style={{ marginTop: 10, borderTop: "1px solid #eee", paddingTop: 10 }}>
              <div style={{ fontWeight: 800, marginBottom: 6 }}>Draft entries</div>

              {!activeTemplate ? (
                <div style={{ color: "#666", fontSize: 12 }}>(no template)</div>
              ) : !draftScoreMap || Object.keys(draftScoreMap).length === 0 ? (
                <div style={{ color: "#666", fontSize: 12 }}>No draft entries yet.</div>
              ) : (
                <div style={{ display: "grid", gap: 6 }}>
                  <div style={{ fontSize: 12, color: "#333" }}>
                    templateId: <span style={{ fontFamily: "ui-monospace, Menlo, monospace" }}>{activeTemplate.id}</span>
                  </div>

                  <div style={{ maxHeight: 180, overflow: "auto", border: "1px solid #f0f0f0", borderRadius: 10, padding: 8 }}>
                    {draftEntriesSorted.slWHITE(0, 200).map((e) => (
                      <div key={e.k} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, marginBottom: 4 }}>
                        <div style={{ fontFamily: "ui-monospace, Menlo, monospace", fontSize: 12 }}>
                          {e.k} : {e.v}
                        </div>
                        <button
                          onClick={() => removeDraftKey(e.k)}
                          style={{ border: "1px solid #ccc", borderRadius: 8, padding: "4px 8px", background: "#fff", cursor: "pointer" }}
                        >
                          remove
                        </button>
                      </div>
                    ))}
                    {draftEntriesSorted.length > 200 && (
                      <div style={{ fontSize: 12, color: "#666" }}>…and {draftEntriesSorted.length - 200} more</div>
                    )}
                  </div>

                  <label style={{ display: "grid", gap: 4 }}>
                    snippet preview
                    <textarea
                      readOnly
                      value={exportDraftSnippet()}
                      style={{
                        width: "100%",
                        minHeight: 120,
                        padding: 8,
                        borderRadius: 10,
                        border: "1px solid #ccc",
                        fontFamily: "ui-monospace, Menlo, monospace",
                        fontSize: 12,
                      }}
                    />
                  </label>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Template mode assigns */}
        {activeTemplate ? (
          <div style={{ marginTop: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, marginBottom: 6 }}>
              <div style={{ fontWeight: 800 }}>Assign tiles & rotations</div>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <button
                  onClick={() => {
                    if (!activeTemplate) return;
                    // SECTORの割当を全て空にする（A案の作業開始点）
                    setAssigns((prev) => {
                      const out = [...prev];
                      for (let i = 0; i < activeTemplate.slots.length; i++) {
                        const s: any = activeTemplate.slots[i];
                        const kind = s?.kind ?? 'SECTOR';
                        if (kind === 'SECTOR') out[i] = { sectorId: '', rot: 0 } as any;
                      }
                      return out;
                    });
                    setVisibleAssignSlotIndWHITEs([]);
                  }}
                  style={{ border: '1px solid #ccc', borderRadius: 10, padding: '6px 10px', background: '#fff', cursor: 'pointer' }}
                >
                  Clear sectors
                </button>

                <button
                  onClick={() => {
                    if (!activeTemplate) return;
                    const nextIdx = activeTemplate.slots.findIndex((s: any, i: number) => {
                      const kind = s?.kind ?? 'SECTOR';
                      return kind === 'SECTOR' && !visibleAssignSlotIndWHITEs.includes(i);
                    });
                    if (nextIdx < 0) return;
                    setVisibleAssignSlotIndWHITEs((prev) => [...prev, nextIdx]);
                  }}
                  style={{ border: '1px solid #ccc', borderRadius: 10, padding: '6px 10px', background: '#fff', cursor: 'pointer' }}
                >
                  Add sector slot
                </button>


                <button
                  onClick={() => {
                    if (!activeTemplate) return;
                    const nextIdx = activeTemplate.slots.findIndex((s: any, i: number) => {
                      const kind = s?.kind ?? 'SECTOR';
                      return kind === 'MIDDLE' && !visibleAssignSlotIndWHITEs.includes(i);
                    });
                    if (nextIdx < 0) return;
                    setVisibleAssignSlotIndWHITEs((prev) => [...prev, nextIdx]);
                  }}
                  style={{ border: '1px solid #ccc', borderRadius: 10, padding: '6px 10px', background: '#fff', cursor: 'pointer' }}
                >
                  Add middle slot
                </button>

                <button
                  onClick={() => {
                    if (!activeTemplate) return;
                    const nextIdx = activeTemplate.slots.findIndex((s: any, i: number) => {
                      const kind = s?.kind ?? 'SECTOR';
                      return kind === 'SMALL' && !visibleAssignSlotIndWHITEs.includes(i);
                    });
                    if (nextIdx < 0) return;
                    setVisibleAssignSlotIndWHITEs((prev) => [...prev, nextIdx]);
                  }}
                  style={{ border: '1px solid #ccc', borderRadius: 10, padding: '6px 10px', background: '#fff', cursor: 'pointer' }}
                >
                  Add small slot
                </button>
              </div>
            </div>

            <div style={{ display: 'grid', gap: 10 }}>
              {visibleAssignSlotIndWHITEs
                .slWHITE()
                .sort((a, b) => a - b)
                .map((idx) => {
                  const s: any = activeTemplate.slots[idx];
                  const kind = s?.kind ?? 'SECTOR';
                  const pos = s?.pos ?? s;
                  const a = assigns[idx] ?? ({ sectorId: '', rot: 0 } as any);
                  const pool = getTilePoolForSlot(activeTemplate, kind);

                  return (
                    <div key={idx} style={{ border: '1px solid #eee', borderRadius: 10, padding: 10 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
                        <div style={{ fontWeight: 700 }}>Slot #{idx + 1} <span style={{ color: '#666', fontSize: 12 }}>({kind})</span></div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                            <div style={{ color: '#666', fontFamily: 'ui-monospace, Menlo, monospace', fontSize: 12 }}>pos</div>
                            <input
                              type="number"
                              value={(posDraftBySlot[idx]?.q ?? String(pos.q)) as any}
                              onChange={(e) => setPosDraftBySlot((prev) => ({ ...prev, [idx]: { q: e.target.value, r: prev[idx]?.r ?? String(pos.r) } }))}
                              onBlur={() => applyPosDraft(idx)}
                              style={{ width: 80, padding: '4px 6px', borderRadius: 8, border: '1px solid #ccc', fontFamily: 'ui-monospace, Menlo, monospace', fontSize: 12 }}
                            />
                            <input
                              type="number"
                              value={(posDraftBySlot[idx]?.r ?? String(pos.r)) as any}
                              onChange={(e) => setPosDraftBySlot((prev) => ({ ...prev, [idx]: { q: prev[idx]?.q ?? String(pos.q), r: e.target.value } }))}
                              onBlur={() => applyPosDraft(idx)}
                              style={{ width: 80, padding: '4px 6px', borderRadius: 8, border: '1px solid #ccc', fontFamily: 'ui-monospace, Menlo, monospace', fontSize: 12 }}
                            />
                            <button
                              onClick={() => applyPosDraft(idx)}
                              style={{ border: '1px solid #ccc', borderRadius: 10, padding: '4px 10px', background: '#fff', cursor: 'pointer', fontSize: 12 }}
                            >
                              Apply
                            </button>
                          </div>
                          <button
                            onClick={() => {
                              setAssigns((prev) => {
                                const out = [...prev];
                                out[idx] = { sectorId: '', rot: 0 } as any;
                                return out;
                              });
                              setVisibleAssignSlotIndWHITEs((prev) => prev.filter((x) => x !== idx));
                            }}
                            style={{ border: '1px solid #ccc', borderRadius: 10, padding: '6px 10px', background: '#fff', cursor: 'pointer' }}
                          >
                            Remove
                          </button>
                        </div>
                      </div>

                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 8 }}>
                        <label style={{ display: 'grid', gap: 4 }}>
                          tileId
                          <select
                            value={a.sectorId}
                            onChange={(e) => updateAssignNoDup(idx, { ...a, sectorId: e.target.value })}
                            style={{ padding: 6, borderRadius: 8, border: '1px solid #ccc' }}
                          >
                            <option value="">(empty)</option>
                            {pool.map((id) => (
                              <option key={id} value={id}>
                                {id}
                              </option>
                            ))}
                          </select>
                        </label>

                        <label style={{ display: 'grid', gap: 4 }}>
                          rot (0..5)
                          <input
                            type="number"
                            min={0}
                            max={5}
                            value={a.rot}
                            onChange={(e) => updateAssignNoDup(idx, { ...a, rot: Number(e.target.value) })}
                            style={{ padding: 6, borderRadius: 8, border: '1px solid #ccc' }}
                          />
                        </label>
                      </div>
                    </div>
                  );
                })}

              {visibleAssignSlotIndWHITEs.length === 0 && (
                <div style={{ color: '#666', fontSize: 12, padding: 10, border: '1px dashed #ddd', borderRadius: 10 }}>
                  0件スタートです。まずは「Add sector slot」でSECTORを1つずつ追加してください。
                </div>
              )}
            </div>
          </div>
        ) : (
          <div style={{ marginTop: 12, color: '#666' }}>テンプレ未選択です。Freezeしてテンプレを作成してください。</div>
        )}

        {/* Freeze */}
        <div style={{ marginTop: 14, borderTop: "1px solid #eee", paddingTop: 14 }}>
          <div style={{ fontWeight: 900, marginBottom: 8 }}>Freeze current map as a new template</div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            <label style={{ display: "grid", gap: 4, gridColumn: "1 / span 2" }}>
              label
              <input
                value={freezeLabel}
                onChange={(e) => setFreezeLabel(e.target.value)}
                style={{ padding: 6, borderRadius: 8, border: "1px solid #ccc" }}
              />
            </label>

            <label style={{ display: "grid", gap: 4 }}>
              players
              <select
                value={freezePlayers}
                onChange={(e) => setFreezePlayers(Number(e.target.value) as 3 | 4)}
                style={{ padding: 6, borderRadius: 8, border: "1px solid #ccc" }}
              >
                <option value={3}>3</option>
                <option value={4}>4</option>
              </select>
            </label>
            <label style={{ fontSize: 12 }}>
              middle tile size
              <input
                type="number"
                step={0.1}
                min={2}
                max={12}
                value={middleTileImgFactor}
                onChange={(e) => setMiddleTileImgFactor(Number(e.target.value))}
                style={{ marginLeft: 6, width: 72 }}
              />
            </label>

            <label style={{ display: "grid", gap: 4 }}>
              expansion
              <select
                value={freezeExp}
                onChange={(e) => setFreezeExp(e.target.value as ExpansionKind)}
                style={{ padding: 6, borderRadius: 8, border: "1px solid #ccc" }}
              >
                <option value="base">base</option>
                <option value="exp">exp</option>
              </select>
            </label>
            <label style={{ fontSize: 12 }}>
              middle tile size
              <input
                type="number"
                step={0.1}
                min={2}
                max={12}
                value={middleTileImgFactor}
                onChange={(e) => setMiddleTileImgFactor(Number(e.target.value))}
                style={{ marginLeft: 6, width: 72 }}
              />
            </label>
</div>

          <button
            onClick={freezeAsNewTemplate}
            style={{
              marginTop: 10,
              width: "100%",
              border: "1px solid #ccc",
              borderRadius: 10,
              padding: "10px 12px",
              background: "#fff",
              cursor: "pointer",
            }}
          >
            Freeze {"->"} Create template
          </button>

          <div style={{ color: "#666", fontSize: 12, marginTop: 8 }}>
            現在の placements.pos を slots として保存します（後から sectorId/rot だけ差し替え可能）。
          </div>
        </div>

        {/* Errors / constraints */}
        <div style={{ marginTop: 14, borderTop: "1px solid #eee", paddingTop: 14 }}>
          <div style={{ fontWeight: 900, marginBottom: 8 }}>Logic (fixed)</div>
          <div style={{ color: "#666", fontSize: 12 }}>
            viewRot60: {VIEW_ROT60}（{VIEW_ROT60 * 60}°） / mirror: {String(VIEW_MIRROR)}
            <br />
            local column shift: 3rd:+1, 4th:+1, 5th:+2
          </div>

          {buildError && (
            <div style={{ marginTop: 12, border: "1px solid #f2c2c2", background: "#fff5f5", padding: 10, borderRadius: 10 }}>
              <div style={{ fontWeight: 800, color: "#b00020" }}>Build error</div>
              <div style={{ fontFamily: "ui-monospace, Menlo, monospace", fontSize: 12, marginTop: 6 }}>{buildError}</div>
            </div>
          )}

          <div style={{ marginTop: 12, borderTop: "1px solid #eee", paddingTop: 12 }}>
            <div style={{ fontWeight: 800, marginBottom: 6 }}>Constraint violations (dist ≤ 2)</div>
            {!mounted ? (
            <div style={{ padding: 12, color: "#666" }}>Mounting…</div>
          ) : board.cells.size === 0 ? (
              <div style={{ color: "#666" }}>No board (build error)</div>
            ) : violations.length === 0 ? (
              <div style={{ color: "#2e7d32" }}>No violations</div>
            ) : (
              <div style={{ display: "grid", gap: 6 }}>
                {violations.map((v, i) => (
                  <div key={i} style={{ fontFamily: "ui-monospace, Menlo, monospace", fontSize: 12 }}>
                    {v.tag} : {v.aKey} ↔ {v.bKey} (d={v.dist})
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Right */}
      <div style={{ border: "1px solid #ddd", borderRadius: 10, padding: 12 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 12 }}>
          <div style={{ fontWeight: 900 }}>Fine Board (Rendered)</div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ fontSize: 12, color: "#333" }}>表示</div>
            <select
              value={renderMode}
              onChange={(e) => setRenderMode(e.target.value as RenderMode)}
              style={{ padding: "6px 8px", borderRadius: 8, border: "1px solid #ccc", fontSize: 12 }}
            >
              <option value="tiles">タイル</option>
              <option value="cells">文字</option>
            </select>
          </div>

          {renderMode === "tiles" && (
            <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
              <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: "#333" }}>
                middle tile size
                <input
                  type="number"
                  step={0.1}
                  min={2}
                  max={12}
                  value={middleTileImgFactor}
                  onChange={(e) => setMiddleTileImgFactor(Number(e.target.value))}
                  style={{ width: 72, padding: "4px 6px", borderRadius: 8, border: "1px solid #ccc", fontSize: 12 }}
                />
              </label>

              <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: "#333" }}>
                middle offsetX
                <input
                  type="number"
                  step={1}
                  value={middleTileOffsetX}
                  onChange={(e) => setMiddleTileOffsetX(Number(e.target.value))}
                  style={{ width: 72, padding: "4px 6px", borderRadius: 8, border: "1px solid #ccc", fontSize: 12 }}
                />
              </label>

              <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: "#333" }}>
                middle offsetY
                <input
                  type="number"
                  step={1}
                  value={middleTileOffsetY}
                  onChange={(e) => setMiddleTileOffsetY(Number(e.target.value))}
                  style={{ width: 72, padding: "4px 6px", borderRadius: 8, border: "1px solid #ccc", fontSize: 12 }}
                />
              </label>

              <button
                onClick={() => {
                  setMiddleTileOffsetX(0);
                  setMiddleTileOffsetY(0);
                }}
                style={{ border: "1px solid #ccc", borderRadius: 10, padding: "6px 10px", background: "#fff", cursor: "pointer", fontSize: 12 }}
              >
                Reset offset
              </button>
            </div>
          )}

          {/* 調整UI（tile size / 回転 / debug表示など）は不要になったため非表示にしています。必要になれば、以前のUIを復帰できます。 */}
        </div>

        <div style={{ width: "100%", height: "80vh", overflow: "hidden", border: "1px solid #eee", borderRadius: 10, marginTop: 8, display: "flex", alignItems: "center", justifyContent: "center" }}>
          {board.cells.size === 0 && <div style={{ padding: 12, color: "#666" }}>No render (build error)</div>}

          {board.cells.size > 0 && renderMode === "cells" && (
            <svg viewBox={`${safeVb.x} ${safeVb.y} ${safeVb.w} ${safeVb.h}`} width="100%" height="100%" preserveAspectRatio="xMidYMid meet" style={{ display: "block" }}>
              {renderKeys.map((k) => {
                const cell = board.cells.get(k)!;
                const a = parseKey(k);
        if (!Number.isFinite((a as any)?.q) || !Number.isFinite((a as any)?.r)) return;
                const { x, y } = axialToPixel(a, size, ORIENTATION);
                const isPlanet = cell.kind === "planet";
                const isPicked = pickedKeys.has(k);
                const isHover = hoverKey === k;

                const draftScore = (draftScoreMap ?? {})[k];
                const hasDraftScore = typeof draftScore === "number";

                const stroke = isPicked ? "#111" : isPlanet ? "#111" : "#bbb";
                const strokeWidth = isPicked ? 4 : isHover ? 3 : isPlanet ? 2 : 1;

                // クリックしやすく：透明でも fill を入れて当たり判定を面にする
                const fill = isPicked
                  ? "rgba(0,0,0,0.10)"
                  : isHover
                  ? "rgba(0,0,0,0.06)"
                  : hasDraftScore
                  ? "rgba(0,0,0,0.03)"
                  : "rgba(0,0,0,0.00)";

                return (
                  <g key={k}>
                    <polygon
                      points={hexPoints(x, y, size, ORIENTATION)}
                      fill={fill}
                      stroke={stroke}
                      strokeWidth={strokeWidth}
                      style={{ cursor: "pointer" }}
                      onMouseEnter={() => setHoverKey(k)}
                      onMouseLeave={() => setHoverKey((prev) => (prev === k ? "" : prev))}
                      onClick={() => {
                        if (slotEditMode === "editPos" && editingSlotIndex != null && activeTemplate) {
                          const a = parseKey(k);
        if (!Number.isFinite((a as any)?.q) || !Number.isFinite((a as any)?.r)) return;
                          updateTemplateSlotPos(editingSlotIndex, { q: a.q, r: a.r });
                          return;
                        }
                        togglePickedKey(k);
                      }}
                    />

                    {isPlanet && (
                      <text x={x} y={y + 4} textAnchor="middle" fontSize={10} style={{ userSelect: "none" }} pointerEvents="none">
                        {planetLabel(cell)}
                      </text>
                    )}

                    {(isHover || isPicked) && (
                      <text
                        x={x}
                        y={y + 18}
                        textAnchor="middle"
                        fontSize={10}
                        style={{ userSelect: "none", fontFamily: "ui-monospace, Menlo, monospace" }}
                       pointerEvents="none">
                        {k}
                      </text>
                    )}

                    {hasDraftScore && (
                      <text
                        x={x}
                        y={y - 10}
                        textAnchor="middle"
                        fontSize={10}
                        style={{ userSelect: "none", fontFamily: "ui-monospace, Menlo, monospace" }}
                       pointerEvents="none">
                        {draftScore > 0 ? `+${draftScore}` : String(draftScore)}
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>
          )}

          {board.cells.size > 0 && renderMode === "tiles" && (
            <svg viewBox={`${safeVb.x} ${safeVb.y} ${safeVb.w} ${safeVb.h}`} width="100%" height="100%" preserveAspectRatio="xMidYMid meet" style={{ display: "block" }}>
              {logicPlacements.map((p, i) => {
                const viewPos = rotate60(p.pos, (tileMapRot60 + 600) % 6);
                const { x, y } = axialToPixel(viewPos, size, ORIENTATION);
                const isMiddle = (p as any)?.kind === "MIDDLE";
                const factor = isMiddle ? middleTileImgFactor : SECTOR_TILE_IMG_FACTOR;
                const imgSize = size * factor;
                const rotBase = rot6((p as any).rot);
                const rotForDraw = isMiddle ? (rotBase + MIDDLE_DRAW_ROT_OFFSET) % 6 : rotBase;
                const deg = tileRotDir * ((rotForDraw + tileRotOffset60 + tileMapRot60) * 60) + tileRotOffsetDeg;

                const off = isMiddle ? (MIDDLE_TILE_OFFSETS[rotForDraw] ?? { x: 0, y: 0 }) : { x: 0, y: 0 };
                const xx = x + off.x;
                const yy = y + off.y;
return (
                  <g key={i} transform={`translate(${xx}, ${yy}) rotate(${deg}) translate(${-imgSize / 2}, ${-imgSize / 2})`}>
                    <image
                      href={`/sectors/${normalizeSectorIdForAssets(p.sectorId)}.png`}
                      width={imgSize}
                      height={imgSize}
                      preserveAspectRatio="xMidYMid meet"
                      pointerEvents="none"
                    />
                  </g>
                );
              })}
            </svg>
          )}

        </div>
      </div>
    </div>
  );
}