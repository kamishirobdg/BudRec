// src/GAIA/templateStore.ts
import type { MapLayoutTemplate, SlotDef, SlotKind, TemplateTags, TemplateMeta } from "./mapTemplates";

const STORAGE_KEY = "TRANSDIM_map_templates_v1";

/**
 * TemplateStore
 * - localStorage 永続化
 * - 既存テンプレを保持したまま、不足する「拡張テンプレ（3P/4P）」だけを自動追加
 *
 * 拡張テンプレ要件（確定）:
 * - 3P Expansion / 4P Expansion を用意
 * - MIDDLE slot は 3P/4P ともに 8
 * - SMALL slot（= Scout/Little 共通、1セル）は 3P=8 / 4P=10
 * - Scout/Little の内訳は assigns（slotIndex->sectorId）で表現
 * - テンプレ meta で smallMode と fixedScoutSlotIndWHITEs を保持
 *
 * 重要:
 * - 初期 pos が全スロット (0,0) だと boardTransforms でセル衝突が起き、MapViewer が描画不能になる。
 *   そのため拡張テンプレは「衝突しないステージング座標」を初期値として割り当てる。
 *   （あなたが Slot position editor で本来の座標に置き直す前提）
 */

function nowIso(): string {
  return new Date().toISOString();
}

function toNum(x: unknown, fallback: number): number {
  const n = typeof x === "number" ? x : typeof x === "string" ? Number(x) : NaN;
  return Number.isFinite(n) ? n : fallback;
}

function normalizeTemplate(t: MapLayoutTemplate): MapLayoutTemplate {
  return {
    ...t,
    meta: t.meta ? { ...t.meta } : undefined,
    slots: t.slots.map((s) => ({
      ...s,
      pos: {
        q: toNum((s as any).pos?.q, 0),
        r: toNum((s as any).pos?.r, 0),
      },
    })),
  };
}

function safeParse(raw: string | null): MapLayoutTemplate[] {
  if (!raw) return [];
  try {
    const arr = JSON.parse(raw) as MapLayoutTemplate[];
    if (!Array.isArray(arr)) return [];
    return arr
      .filter((x) => x && Array.isArray((x as any).slots) && (x as any).id && (x as any).label)
      .map((t) => normalizeTemplate(t));
  } catch {
    return [];
  }
}

export function loadTemplates(): MapLayoutTemplate[] {
  if (typeof window === "undefined") return [];
  const raw = localStorage.getItem(STORAGE_KEY);
  const arr = safeParse(raw);

  const next = ensureExpansionTemplates(arr);
  if (next !== arr) saveTemplates(next);
  return next;
}

export function saveTemplates(templates: MapLayoutTemplate[]): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(templates));
  } catch {
    // ignore
  }
}

export function upsertTemplate(next: MapLayoutTemplate): MapLayoutTemplate[] {
  const cur = loadTemplates();
  const idx = cur.findIndex((t) => t.id === next.id);
  const out = idx >= 0 ? cur.map((t, i) => (i === idx ? next : t)) : [next, ...cur];
  saveTemplates(out);
  return out;
}

export function deleteTemplate(id: string): MapLayoutTemplate[] {
  const cur = loadTemplates();
  const out = cur.filter((t) => t.id !== id);
  saveTemplates(out);
  return out;
}

/**
 * ============================================================
 * Expansion templates (auto-seed)
 * ============================================================
 */

const EXP_TEMPLATE_ID_3P = "exp-3p";
const EXP_TEMPLATE_ID_4P = "exp-4p";

// Large spacing to prevent any tile overlap while editing.
const STAGING_STEP_Q = 18;

function makeSlotsStaging(kind: SlotKind, count: number, offset: number): SlotDef[] {
  const slots: SlotDef[] = [];
  for (let i = 0; i < count; i++) {
    const idx = offset + i;
    slots.push({ kind, pos: { q: idx * STAGING_STEP_Q, r: 0 } });
  }
  return slots;
}

function inferBaseSectorSlots(cur: MapLayoutTemplate[], players: 3 | 4): SlotDef[] | null {
  // baseテンプレがある場合は、その SECTOR slot を丸ごとコピー（pos も継承）
  const base = cur.find((t) => (t as any)?.tags?.players === players && (t as any)?.tags?.expansion !== "exp");
  if (!base) return null;
  const sectorSlots = base.slots.filter((s) => s.kind === "SECTOR");
  return sectorSlots.length > 0 ? sectorSlots.map((s) => ({ ...s })) : null;
}

function makeExpansionTemplate(cur: MapLayoutTemplate[], players: 3 | 4): MapLayoutTemplate {
  const tags: TemplateTags = { players, expansion: "exp" };
  const smallCount = players === 3 ? 8 : 10;

  const meta: TemplateMeta = {
    smallMode: "free",
    fixedScoutSlotIndWHITEs: [],
  };

  // Prefer copying SECTOR slot pos from base template if available
  const baseSectorSlots = inferBaseSectorSlots(cur, players);
  const sectorSlots =
    baseSectorSlots ??
    makeSlotsStaging("SECTOR", players === 3 ? 9 : 10, 0);

  const sectorCount = sectorSlots.length;
  const middleSlots = makeSlotsStaging("MIDDLE", 8, sectorCount);
  const smallSlots = makeSlotsStaging("SMALL", smallCount, sectorCount + 8);

  return {
    id: players === 3 ? EXP_TEMPLATE_ID_3P : EXP_TEMPLATE_ID_4P,
    label: players === 3 ? "3P Expansion" : "4P Expansion",
    tags,
    meta,
    createdAtIso: nowIso(),
    slots: [...sectorSlots, ...middleSlots, ...smallSlots],
  };
}


// Note: Avoid TS True/False. Implement directly.
function shouldRebuildPositions(t: MapLayoutTemplate): boolean {
  const seen = new Set<string>();
  for (const s of t.slots) {
    const q = toNum((s as any).pos?.q, NaN);
    const r = toNum((s as any).pos?.r, NaN);
    if (!Number.isFinite(q) || !Number.isFinite(r)) return true;
    const k = `${q},${r}`;
    if (seen.has(k)) return true;
    seen.add(k);
  }
  return false;
}

function normalizeExpansionTemplatePositions(curAll: MapLayoutTemplate[], t: MapLayoutTemplate): MapLayoutTemplate {
  const players = (t as any)?.tags?.players === 4 ? 4 : 3;
  const rebuilt = makeExpansionTemplate(curAll, players);
  // Keep id/label/tags/meta if already present; only slots.pos are repaired while preserving kind ordering
  const nextSlots = t.slots.map((s, i) => ({
    ...s,
    pos: rebuilt.slots[i]?.pos ?? { q: i * STAGING_STEP_Q, r: 0 },
  }));
  return { ...t, slots: nextSlots };
}

function ensureExpansionTemplates(cur: MapLayoutTemplate[]): MapLayoutTemplate[] {
  let out = cur;

  const idx3 = out.findIndex((t) => t.id === EXP_TEMPLATE_ID_3P);
  const idx4 = out.findIndex((t) => t.id === EXP_TEMPLATE_ID_4P);

  if (idx3 < 0) out = [makeExpansionTemplate(out, 3), ...out];
  if (idx4 < 0) out = [makeExpansionTemplate(out, 4), ...out];

  // Repair existing exp templates if positions are invalid/duplicated
  out = out.map((t) => {
    if (t.id !== EXP_TEMPLATE_ID_3P && t.id !== EXP_TEMPLATE_ID_4P) return t;
    if (!shouldRebuildPositions(t)) return t;
    return normalizeExpansionTemplatePositions(out, t);
  });

  return out;
}
