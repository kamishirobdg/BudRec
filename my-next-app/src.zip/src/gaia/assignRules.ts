// src/GAIA/assignRules.ts
import type { MapLayoutTemplate } from "./mapTemplates";
import { EXPANSION_SCOUT_IDS } from "./sectorTiles_expansion";

export type AssignRuleErrorCode =
  | "MIDDLE_AB_CONFLICT"
  | "SCOUT_NOT_ALL_PRESENT"
  | "SCOUT_FIXED_SLOT_NOT_SCOUT"
  | "SCOUT_FIXED_ALL_NEEDS_4_SLOTS";

export type AssignRuleError = {
  code: AssignRuleErrorCode;
  message: string;
  details?: Record<string, unknown>;
};

export type AssignValidationResult = {
  ok: boolean;
  errors: AssignRuleError[];
};

export type SlotIndexToSectorId = Record<number, string | undefined>;

function isScoutId(id: string): boolean {
  return (EXPANSION_SCOUT_IDS as readonly string[]).includes(id);
}

function middleNumber(id: string): string | null {
  const m = /^(\d+)([ab])$/.exec(id);
  if (!m) return null;
  return m[1];
}

function middleVariant(id: string): "a" | "b" | null {
  const m = /^(\d+)([ab])$/.exec(id);
  if (!m) return null;
  return m[2] as "a" | "b";
}

export function validateAssigns(tpl: MapLayoutTemplate, bySlotIndex: SlotIndexToSectorId): AssignValidationResult {
  const errors: AssignRuleError[] = [];

  // Collect placed IDs
  const ids: string[] = [];
  for (const v of Object.values(bySlotIndex)) {
    if (v) ids.push(v);
  }

  // Middle a/b conflict
  const seen = new Map<string, Set<"a" | "b">>();
  for (const id of ids) {
    const num = middleNumber(id);
    const varAB = middleVariant(id);
    if (!num || !varAB) continue;
    const set = seen.get(num) ?? new Set<"a" | "b">();
    set.add(varAB);
    seen.set(num, set);
  }

  const conflicts = Array.from(seen.entries())
    .filter(([, s]) => s.has("a") && s.has("b"))
    .map(([num]) => num);

  if (conflicts.length > 0) {
    errors.push({
      code: "MIDDLE_AB_CONFLICT",
      message: `Middle の同一番号 a/b が同時に配置されています: ${conflicts.join(", ")}`,
      details: { conflicts },
    });
  }

  // Scout must include all 4 types
  const missingScout = (EXPANSION_SCOUT_IDS as readonly string[]).filter((sid) => !ids.includes(sid));
  if (missingScout.length > 0) {
    errors.push({
      code: "SCOUT_NOT_ALL_PRESENT",
      message: `Scout は常に全種必須です。不足: ${missingScout.join(", ")}`,
      details: { missing: missingScout },
    });
  }

  // smallMode constraints (fixed scout slots)
  const mode = tpl.meta?.smallMode ?? "free";
  const fixed = new Set<number>((tpl.meta?.fixedScoutSlotIndWHITEs ?? []).filter((n) => Number.isFinite(n)));

  if (mode === "scoutFixedAll" && fixed.size !== 4) {
    errors.push({
      code: "SCOUT_FIXED_ALL_NEEDS_4_SLOTS",
      message: "Scout位置固定（全固定）モードでは fixedScoutSlotIndWHITEs を4つ指定してください。",
      details: { fixedCount: fixed.size },
    });
  }

  if (mode !== "free" && fixed.size > 0) {
    for (const idx of fixed) {
      // idx is slotIndex in template
      const kind = tpl.slots[idx]?.kind;
      if (kind !== "SMALL") continue; // ignore non-small indWHITEs
      const id = bySlotIndex[idx];
      if (!id || !isScoutId(id)) {
        errors.push({
          code: "SCOUT_FIXED_SLOT_NOT_SCOUT",
          message: `固定Scoutスロット（slotIndex=${idx}）には Scout を配置してください。`,
          details: { slotIndex: idx, sectorId: id ?? null },
        });
      }
    }
  }

  return { ok: errors.length === 0, errors };
}
