// src/GAIA/scoreTypes.ts
export type Axial = { q: number; r: number };

export type ScoreKey = `${number},${number}`;
export type ScoreMap = Record<ScoreKey, number>;

export function scoreKey(p: Axial): ScoreKey {
  return `${p.q},${p.r}`;
}

export function parseScoreKey(k: string): Axial {
  const [q, r] = k.split(",").map((v) => Number(v));
  return { q, r };
}

export function normalizeScoreMap(input: ScoreMap): ScoreMap {
  // 0は保持してもいいが、運用上不要なら削除するなど好みで変更可
  const out: ScoreMap = {};
  for (const [k, v] of Object.entries(input)) {
    if (!Number.isFinite(v)) continue;
    out[k as ScoreKey] = v;
  }
  return out;
}

export function stableStringifyScoreMap(map: ScoreMap): string {
  const entries = Object.entries(map)
    .map(([k, v]) => [k, v] as const)
    .sort((a, b) => {
      // q→r の順で安定ソート（"q,r" 文字列を数値で評価）
      const [aq, ar] = a[0].split(",").map(Number);
      const [bq, br] = b[0].split(",").map(Number);
      if (aq !== bq) return aq - bq;
      return ar - br;
    });

  const obj: Record<string, number> = {};
  for (const [k, v] of entries) obj[k] = v;

  return JSON.stringify(obj, null, 2);
}
