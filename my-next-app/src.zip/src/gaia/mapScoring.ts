// src/GAIA/mapScoring.ts
import type { Cell, PlanetType } from "./sectorTypes";

export type ScoreMap = Record<string, number>;

export type ScorePerType = {
  totals: Record<PlanetType, number>;
  counts: Record<PlanetType, number>;
  avgs: Record<PlanetType, number>;
};

export type BalanceMetrics = {
  // mean of per-type average score (avgByType)
  meanAvg: number;
  // L1 deviation from mean: Σ |avg_t - meanAvg|
  l1: number;
  // L2 deviation from mean: Σ (avg_t - meanAvg)^2
  l2: number;
  // max |avg_t - meanAvg|
  maxAbs: number;
  includedTypes: PlanetType[];
};

export type ScoreBreakdownItem =
  | {
      key: string;
      score: number;
      kind: "empty";
    }
  | {
      key: string;
      score: number;
      kind: "planet";
      planet: PlanetType;
    };

export type ScoreBoardResult = {
  total: number;
  breakdown: ScoreBreakdownItem[];
  perType: ScorePerType;

  /**
   * balance:
   * - existing metrics (kept for diagnostics / UI)
   * NOTE: These are computed over per-type *averages per planet cell* (avgs).
   */
  balance: BalanceMetrics;

  /**
   * SSOT-aligned outputs for history:
   * - dispersionValue: normalized MAD over planetScores (L1-based, dimensionless)
   * - planetScores: per-PlanetType totals used as inputs to dispersionValue
   *
   * IMPORTANT:
   * - planetScores are the values used to compute dispersionValue.
   * - Callers may feed a scoreMap that already includes neighbor/GAIA/etc. effects.
   */
  dispersionValue: number;
  planetScores: Record<PlanetType, number>;
};

const EXCLUDED_FOR_BALANCE = new Set<PlanetType>(["TRANSDIM", "GAIA"]);

export const INCLUDED_TYPES_9: PlanetType[] = [
  "BLUE",
  "YELLOW",
  "BROWN",
  "RED",
  "WHITE",
  "ORANGE",
  "BLACK",
  "PROTO",
  "ASTEROID",
];

function isPlanetCell(cell: Cell): cell is Extract<Cell, { kind: "planet" }> {
  return cell.kind === "planet";
}

/**
 * Score a board given:
 * - cells: all placed cells (including empties)
 * - scoreMap: per-cell score contribution keyed by axial key string
 *
 * This function:
 * - sums total score
 * - aggregates per-planet-type totals/counts/avgs (9 types)
 * - computes diagnostic balance metrics over per-type averages (balance.*)
 * - computes SSOT dispersionValue over per-type totals (planetScores)
 */
export function scoreBoard(cells: Record<string, Cell>, scoreMap: ScoreMap): ScoreBoardResult {
  let total = 0;
  const breakdown: ScoreBreakdownItem[] = [];

  // totals/counts for the 7 balance types
  const totals = Object.fromEntries(INCLUDED_TYPES_9.map((t) => [t, 0])) as Record<
    PlanetType,
    number
  >;
  const counts = Object.fromEntries(INCLUDED_TYPES_9.map((t) => [t, 0])) as Record<
    PlanetType,
    number
  >;

  for (const [key, cell] of Object.entries(cells)) {
    const s = scoreMap[key] ?? 0;
    total += s;

    if (isPlanetCell(cell)) {
      breakdown.push({ key, score: s, kind: "planet", planet: cell.planet });

      // balance対象の7種に限定（TRANSDIM/GAIA除外＋7種のみ）
      if (!EXCLUDED_FOR_BALANCE.has(cell.planet) && cell.planet in totals) {
        totals[cell.planet] += s;
        counts[cell.planet] += 1;
      }
    } else {
      breakdown.push({ key, score: s, kind: "empty" });
    }
  }

  // averages (per planet cell of each type)
  const avgs = Object.fromEntries(INCLUDED_TYPES_9.map((t) => [t, 0])) as Record<PlanetType, number>;
  for (const t of INCLUDED_TYPES_9) {
    const c = counts[t] || 0;
    avgs[t] = c > 0 ? totals[t] / c : 0;
  }

  // balance metrics over 9 types (even if count=0, avg=0; this is intentional)
  // ※「その種が出ない」こと自体が偏りを強める可能性があるため。
  //   もし “出ない種は評価対象外” にしたくなったら、ここを counts>0 のみにする。
  const meanAvg = INCLUDED_TYPES_9.reduce((acc, t) => acc + avgs[t], 0) / INCLUDED_TYPES_9.length;

  let l1 = 0;
  let l2 = 0;
  let maxAbs = 0;
  for (const t of INCLUDED_TYPES_9) {
    const d = avgs[t] - meanAvg;
    const ad = Math.abs(d);
    l1 += ad;
    l2 += d * d;
    if (ad > maxAbs) maxAbs = ad;
  }

  // ---------------------------------------------------------------------------
  // SSOT-aligned dispersionValue over per-type totals (planetScores)
  // dispersionValue = MAD(vals) / avgAbs(vals)
  // where vals are totals for the 9 types (missing types are 0 by construction)
  // ---------------------------------------------------------------------------
  const vals = INCLUDED_TYPES_9.map((t) => totals[t]);
  const mean = vals.reduce((a, v) => a + v, 0) / vals.length;

  const mad = vals.reduce((a, v) => a + Math.abs(v - mean), 0) / vals.length;

  const avgAbsRaw = vals.reduce((a, v) => a + Math.abs(v), 0) / vals.length;
  const avgAbs = avgAbsRaw > 1e-9 ? avgAbsRaw : 1;

  const dispersionValue = mad / avgAbs;

  return {
    total,
    breakdown,
    perType: { totals, counts, avgs },
    balance: {
      meanAvg,
      l1,
      l2,
      maxAbs,
      includedTypes: INCLUDED_TYPES_9,
    },

    // SSOT outputs
    dispersionValue,
    planetScores: totals,
  };
}
