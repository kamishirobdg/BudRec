// src/GAIA/hexLayout.ts
import type { Axial } from "./sectorTypes";
import { rotate60 } from "./axialMath";

export type HexOrientation = "pointy" | "flat";

/**
 * 6回転＋反転（mirror）でビュー座標を調整する
 * - viewRot60: 0..5 （60度単位）
 * - viewMirror: true のとき鏡映（y<->z swap 相当）を適用
 *
 * 目的：/map の「上方向」「左右」をユーザーの想定に合わせて変えられるようにする
 */
export function applyViewTransform(p: Axial, viewRot60: number, viewMirror: boolean): Axial {
  const rot = ((viewRot60 % 6) + 6) % 6;

  // cube: x=q, z=r, y=-x-z
  let x = p.q;
  let z = p.r;
  let y = -x - z;

  if (viewMirror) {
    // 代表的な鏡映：y と z を入れ替える（dihedral group の反転の一つ）
    const tmp = y;
    y = z;
    z = tmp;
  }

  // 60度回転（cube回転）
  // rotate60() は axial で定義されているので、mirror後に cube を axial に戻してから回す
  // ただし cube のまま回した方が素直なので、ここで回す
  for (let i = 0; i < rot; i++) {
    const nx = -z;
    const ny = -x;
    const nz = -y;
    x = nx;
    y = ny;
    z = nz;
  }

  return { q: x, r: z };
}

/**
 * Axial(q,r) -> pixel
 * - pointy-top / flat-top の両対応
 */
export function axialToPixel(p: Axial, size: number, orientation: HexOrientation): { x: number; y: number } {
  if (orientation === "pointy") {
    // pointy-top
    // x = size * sqrt(3) * (q + r/2)
    // y = size * 3/2 * r
    const x = size * Math.sqrt(3) * (p.q + p.r / 2);
    const y = size * (3 / 2) * p.r;
    return { x, y };
  }

  // flat-top
  // x = size * 3/2 * q
  // y = size * sqrt(3) * (r + q/2)
  const x = size * (3 / 2) * p.q;
  const y = size * Math.sqrt(3) * (p.r + p.q / 2);
  return { x, y };
}

/** ヘックスの頂点座標（SVG polygon points） */
export function hexPoints(cx: number, cy: number, size: number, orientation: HexOrientation): string {
  // pointy: -30deg start, flat: 0deg start
  const startDeg = orientation === "pointy" ? -30 : 0;
  const pts: Array<[number, number]> = [];
  for (let i = 0; i < 6; i++) {
    const ang = (Math.PI / 180) * (60 * i + startDeg);
    pts.push([cx + size * Math.cos(ang), cy + size * Math.sin(ang)]);
  }
  return pts.map(([x, y]) => `${x},${y}`).join(" ");
}

export function parseKey(k: string): Axial {
  const [q, r] = k.split(",").map(Number);
  return { q, r };
}
