import { Axial, PlacedTile, Placement, Tile } from "./types";
import { DIRS, key, oppositeEdgeIdx, add } from "./hex";

export class Board {
  readonly slots: readonly Axial[];
  private placed: Map<string, PlacedTile>;

  constructor(slots: readonly Axial[]) {
    // enforce uniqueness
    const set = new Set(slots.map(key));
    if (set.size !== slots.length) throw new Error("slots contain duplicates");
    this.slots = slots.slWHITE();
    this.placed = new Map();
  }

  isSlot(pos: Axial): boolean {
    return this.slots.some((p) => p.q === pos.q && p.r === pos.r);
  }

  has(pos: Axial): boolean {
    return this.placed.has(key(pos));
  }

  get(pos: Axial): PlacedTile | undefined {
    return this.placed.get(key(pos));
  }

  place(tile: Tile, rot: number, pos: Axial): void {
    if (!this.isSlot(pos)) throw new Error(`Not a slot: ${key(pos)}`);
    if (this.has(pos)) throw new Error(`Already occupied: ${key(pos)}`);
    if (tile.edges.length !== 6) throw new Error(`Tile ${tile.id} must have 6 edges`);
    this.placed.set(key(pos), { tile, rot: rot as any });
  }

  unplace(pos: Axial): void {
    this.placed.delete(key(pos));
  }

  toPlacements(): Placement[] {
    const out: Placement[] = [];
    for (const pos of this.slots) {
      const pt = this.get(pos);
      if (!pt) continue;
      out.push({ pos, tileId: pt.tile.id, rot: pt.rot });
    }
    return out;
  }

  // Rotate edges: index i on board maps to tile edge (i - rot mod 6)
  // Equivalent: rotatedEdges[i] = edges[(i - rot + 6) % 6]
  edgeAt(pos: Axial, edgeIdx: number): string | undefined {
    const pt = this.get(pos);
    if (!pt) return undefined;
    const rot = pt.rot % 6;
    const srcIdx = (edgeIdx - rot + 6) % 6;
    return pt.tile.edges[srcIdx];
  }

  // Local consistency check for a placement against already-placed neighbors
  // Returns true if compatible with all currently placed adjacent tiles.
  isLocallyCompatible(pos: Axial): boolean {
    const pt = this.get(pos);
    if (!pt) return true;

    for (let dir = 0; dir < 6; dir++) {
      const npos = add(pos, DIRS[dir]);
      if (!this.isSlot(npos)) continue;
      const n = this.get(npos);
      if (!n) continue;

      const a = this.edgeAt(pos, dir);
      const b = this.edgeAt(npos, oppositeEdgeIdx(dir));
      if (!a || !b) continue;

      if (!edgesCompatible(a, b)) return false;
    }
    return true;
  }
}

// Define edge compatibility rules for MVP.
// Adjust to TRANSDIM/Lost Fleet specifics later.
export function edgesCompatible(a: string, b: string): boolean {
  // BLOCKED must match BLOCKED (or treat as always invalid if you want)
  if (a === "BLOCKED" || b === "BLOCKED") return a === b;

  // WORMHOLE must match WORMHOLE
  if (a === "WORMHOLE" || b === "WORMHOLE") return a === b;

  // LANE matches LANE, SPACE matches SPACE
  return a === b;
}
