// src/GAIA/axialMath.ts
import type { Axial } from "./sectorTypes";

export function add(a: Axial, b: Axial): Axial {
  return { q: a.q + b.q, r: a.r + b.r };
}

/**
 * Axial(q,r) を 60度単位で回転（pointy-top想定）
 * rot: 0..5
 *
 * cube変換: x=q, z=r, y=-x-z
 * 60度回転: (x,y,z) -> (-z,-x,-y)
 */
export function rotate60(p: Axial, rot: number): Axial {
  let x = p.q;
  let z = p.r;
  let y = -x - z;

  const k = ((rot % 6) + 6) % 6;
  for (let i = 0; i < k; i++) {
    const nx = -z;
    const ny = -x;
    const nz = -y;
    x = nx;
    y = ny;
    z = nz;
  }
  return { q: x, r: z };
}

export function key(p: Axial): string {
  return `${p.q},${p.r}`;
}
