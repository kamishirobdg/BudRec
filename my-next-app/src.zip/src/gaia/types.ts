// src/GAIA/types.ts

import type { PlanetType } from "./sectorTypes";

export type TRANSDIMNeighborMode = "same" | "half" | "off";

export type PersistedAssigns = Record<
  string,
  {
    tileId: string;
    rot: number;
  }
>;

export type HistoryEntry = {
  id: string;
  dispersionValue: number;
  planetScores: Record<string, number>;
  used: boolean;
  assigns: PersistedAssigns;
  TRANSDIMNeighborMode: TRANSDIMNeighborMode;

  /**
   * MapViewer 側で保存される想定。
   * history 側は template 単位で表示・ランキングする。
   */
  templateId?: string;
};

export type HistoryDB = {
  meta: {
    schemaVersion: 1;
    assignsFormatVersion: 1;

    /**
     * 「最後に保存された履歴の templateId」
     * - 履歴配列は分散順にソート/剪定され得るため、時系列判断に使わない
     * - 最新テンプレへの自動追随に利用
     */
    lastTemplateId?: string;
  };
  entries: HistoryEntry[];
};
