// src/GAIA/sectorPools.ts
import { BASE_SECTORS } from "./sectorTiles_base";
import { EXPANSION_MIDDLE_IDS } from "./sectorTiles_expansion";

/**
 * MapViewerの「デフォルト割当のプール」用途。
 * - base: 通常セクターのみ
 * - exp : 通常セクター + Middleセクター（11a/11b...）
 *
 * ※ Little/Scoutは現状MapViewerのslot種類UIが未導入なので、プールには入れない。
 *    将来slotKind導入後に別プール化するのが安全。
 */

export const BASE_SECTOR_ID_POOL: readonly string[] = BASE_SECTORS.map((s) => s.id);

export const EXP_SECTOR_ID_POOL: readonly string[] = [
  ...BASE_SECTORS.map((s) => s.id),
  ...EXPANSION_MIDDLE_IDS,
];
