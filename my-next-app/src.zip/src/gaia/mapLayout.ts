// src/GAIA/mapLayout.ts
import type { Axial } from "./sectorTypes";

export type MapLayout = {
  name: string;
  slots: Axial[]; // 固定スロット（セクター中心座標）
};

export type SlotAssignment = {
  sectorId: string;
  rot: number; // 0..5
};

export type SectorPlacement = {
  sectorId: string;
  pos: Axial;
  rot: number;
};

export function placementsFromLayout(layout: MapLayout, assigns: SlotAssignment[]): SectorPlacement[] {
  if (layout.slots.length !== assigns.length) {
    throw new Error(
      `Layout slot count mismatch: layout=${layout.slots.length}, assigns=${assigns.length}`
    );
  }
  return assigns.map((a, i) => ({
    sectorId: a.sectorId,
    rot: clampRot(a.rot),
    pos: layout.slots[i],
  }));
}

function clampRot(rot: number): number {
  const n = Number(rot);
  if (!Number.isFinite(n)) return 0;
  const k = ((Math.round(n) % 6) + 6) % 6;
  return k;
}
