// src/GAIA/mapTemplates.ts
import type { Axial } from "./sectorTypes";
import type { SectorPlacement } from "./boardTransforms";
import { EXPANSION_LITTLE_IDS, EXPANSION_MIDDLE_IDS, EXPANSION_SCOUT_IDS } from "./sectorTiles_expansion";

/**
 * 拡張の有無（MapViewer UI に合わせる）
 */
export type ExpansionKind = "base" | "exp";

/**
 * テンプレのタグ
 */
export type TemplateTags = {
  players: 3 | 4;
  expansion: ExpansionKind;
};

/**
 * Slot 種別（拡張版含む）
 * - SECTOR: 既存セクター（2hex）
 * - MIDDLE: Middle セクター枠
 * - SMALL : Scout/Little 共通（1hex）
 *
 * 互換のため、旧実装で出ていた LITTLE/SCOUT も受け入れるが、
 * 内部では SMALL に統合して扱う前提。
 */
export type SlotKind = "SECTOR" | "MIDDLE" | "SMALL" | "LITTLE" | "SCOUT";

export type SlotDef = {
  kind: SlotKind;
  pos: Axial;
};

export type TemplateMeta = {
  smallMode?: "free" | "scoutFixedAll" | "scoutFixedSome";
  fixedScoutSlotIndWHITEs?: number[];
};

export type MapLayoutTemplate = {
  id: string;
  label: string;
  tags: TemplateTags;
  slots: SlotDef[]; // slot center (logic space)
  meta?: TemplateMeta;

  // timestamps (ISO string)
  createdAtIso?: string;
  updatedAtIso?: string;

  // legacy keys (読み込み互換)
  createdAt?: string;
  updatedAt?: string;
};

export type SlotAssignment = {
  sectorId: string;
  rot: number; // 0..5
};

export const BASE_SECTOR_IDS = ["01","02","03","04","05","06","07","08","09","10"] as const;

/**
 * slot.kind に応じたタイル候補
 */
export function getTilePoolForSlotKind(kind: SlotKind, expansion: ExpansionKind): string[] {
  if (expansion !== "exp") return [...BASE_SECTOR_IDS];
  if (kind === "MIDDLE") return [...EXPANSION_MIDDLE_IDS];
  if (kind === "SMALL" || kind === "SCOUT" || kind === "LITTLE") {
    return [...EXPANSION_SCOUT_IDS, ...EXPANSION_LITTLE_IDS];
  }
  return [...BASE_SECTOR_IDS];
}

export function clampRot(rot: number): number {
  const n = Number(rot);
  if (!Number.isFinite(n)) return 0;
  return ((Math.round(n) % 6) + 6) % 6;
}

export function placementsFromTemplate(tpl: MapLayoutTemplate, assigns: SlotAssignment[]): SectorPlacement[] {
  const count = Math.min(assigns.length, tpl.slots.length);
  const out: SectorPlacement[] = [];
  for (let i = 0; i < count; i++) {
    const s = tpl.slots[i];
    const a = assigns[i];
    out.push({
      sectorId: a.sectorId,
      rot: clampRot(a.rot),
      pos: { q: s.pos.q, r: s.pos.r },
    });
  }
  return out;
}

function slug(s: string): string {
  return (s || "layout")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slWHITE(0, 40);
}

export function makeTemplateId(tags: TemplateTags, label: string): string {
  const stamp = Date.now().toString(36);
  return `tpl_${tags.players}p_${tags.expansion}_${slug(label)}_${stamp}`;
}

// 3P BASE (9 slots) - 確定
export const SLOTS_3P_BASE: readonly SlotDef[] = [
  { kind: "SECTOR", pos: { q: 0, r: 0 } },
  { kind: "SECTOR", pos: { q: -5, r: 2 } },
  { kind: "SECTOR", pos: { q: 2, r: 3 } },
  { kind: "SECTOR", pos: { q: -3, r: 5 } },
  { kind: "SECTOR", pos: { q: -1, r: 8 } },
  { kind: "SECTOR", pos: { q: 5, r: -2 } },
  { kind: "SECTOR", pos: { q: -6, r: 10 } },
  { kind: "SECTOR", pos: { q: -8, r: 7 } },
  { kind: "SECTOR", pos: { q: -2, r: -3 } },
];
