// src/GAIA/fineConstraints.ts
import type { Axial, Cell } from "./sectorTypes";

function parseKey(k: string): Axial {
  const [q, r] = k.split(",").map(Number);
  return { q, r };
}

function hexDist(a: Axial, b: Axial): number {
  const dq = a.q - b.q;
  const dr = a.r - b.r;
  const ds = -(a.q + a.r) - (-(b.q + b.r));
  return (Math.abs(dq) + Math.abs(dr) + Math.abs(ds)) / 2;
}

/**
 * 距離制約の対象外となる惑星タグ
 * - TRANSDIM
 * - GAIA
 */
const EXCLUDED_PLANET_TAGS = new Set<string>([
  "planet:TRANSDIM",
  "planet:GAIA",
]);

function planetTagForProximity(cell: Cell): string | null {
  if (cell.kind !== "planet") return null;

  const tags = cell.tags ?? [];
  const t = tags.find((x) => x.startsWith("planet:"));
  if (!t) return null;

  // 対象外惑星は距離制約チェックから除外
  if (EXCLUDED_PLANET_TAGS.has(t)) return null;

  return t;
}

export type ProximityViolation = {
  aKey: string;
  bKey: string;
  tag: string;
  dist: number;
};

/**
 * 同一惑星タイプ同士が指定距離以内に存在する組を検出する
 * @param cells グローバル座標のセルMap
 * @param radius 禁止距離（例: 2）
 */
export function findForbiddenProximityPairs(
  cells: ReadonlyMap<string, Cell>,
  radius: number
): ProximityViolation[] {
  const keys = Array.from(cells.keys());
  const violations: ProximityViolation[] = [];

  for (let i = 0; i < keys.length; i++) {
    const ka = keys[i];
    const ca = cells.get(ka)!;
    const ta = planetTagForProximity(ca);
    if (!ta) continue;

    const a = parseKey(ka);

    for (let j = i + 1; j < keys.length; j++) {
      const kb = keys[j];
      const cb = cells.get(kb)!;
      const tb = planetTagForProximity(cb);
      if (!tb) continue;

      // 同一惑星タイプのみチェック
      if (ta !== tb) continue;

      const b = parseKey(kb);
      const d = hexDist(a, b);

      if (d <= radius) {
        violations.push({
          aKey: ka,
          bKey: kb,
          tag: ta,
          dist: d,
        });
      }
    }
  }

  return violations;
}
