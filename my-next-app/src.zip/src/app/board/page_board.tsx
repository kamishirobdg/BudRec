"use client";

import * as React from "react";
import { MapBoardViewer, type PlacementItem as ViewerPlacementItem } from "@/components/MapBoardViewer";

import { TEMPLATE_3P_LOSTFLEET } from "@/gaia/data/templates/3p_lostFleet";
import { TEMPLATE_4P_LOSTFLEET } from "@/gaia/data/templates/4p_lostFleet";

import { BASE_SECTORS } from "@/gaia/sectorTiles_base";
import { EXPANSION_MIDDLE, EXPANSION_LITTLE, EXPANSION_SCOUT } from "@/gaia/sectorTiles_lostfleet";

import { buildSectorLookup, expandPlacementToBoardCells, type BoardCell } from "@/gaia/board/previewBoard";
import { placementFromSeed } from "@/gaia/board/placementFromSeed";
import { runSearch as runLogicalSearch } from "@/gaia/search";
import { computeConstraintReport, type ConstraintReport } from "@/gaia/board/constraints";

/**
 * ======= ここを編集：固定 Large セット =======
 *
 * 目的：seed を変えても「使用する Large タイル集合」を 3p/4p で固定する。
 *
 * 使い方：
 * - BASE_SECTORS の sectorId（=LargeタイルID）をここに列挙してください。
 * - 3p / 4p それぞれ「Largeスロット数」と同数以上を指定してください。
 * - 長い場合は、必要数より多く指定してもOK（先頭から必要数だけ使用）
 *
 * 暫定：初期状態は ["__AUTO__"] になっています。
 * - このままだと従来同様に BASE_SECTORS の先頭から必要数を採用（動作確認用）
 * - 明示固定したい場合は "__AUTO__" を消してIDを列挙
 */
const FIXED_LARGE_3P: string[] = ["01", "02", "03", "04", "05b", "06b", "07b", "09", "10"];
const FIXED_LARGE_4P: string[] = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10"];

/**
 * ======= ここを編集：固定 Little プール =======
 *
 * 目的：Little の候補集合（19/20/21 以外も含む）を 3p/4p で固定し、
 *       その中から「固定枚数(19/20/21) + 残りを非固定から置換なし」で選ぶ。
 *
 * 前提（SSOT）:
 * - placementFromSeed の Little は deck 方式（置換なし）
 * - littleFixedCounts は 19/20/21 の“固定枚数”
 *
 * 使い方：
 * - EXPANSION_LITTLE の sectorId（=LittleタイルID）をここに列挙してください。
 * - 19/20/21 以外の Little を追加したうえで、ここで候補プールを固定します。
 *
 * 暫定：初期状態は ["__AUTO__"]（=EXPANSION_LITTLE 全体を候補プールにする）
 */
const FIXED_LITTLE_POOL_3P: string[] = ["19", "20", "21", "22"];
const FIXED_LITTLE_POOL_4P: string[] = ["19", "20", "21", "22", "23", "24"];

const BASIC_PLANET_TYPES = ["BLACK", "BLUE", "BROWN", "ORANGE", "RED", "WHITE", "YELLOW"] as const;
type BasicPlanetType = (typeof BASIC_PLANET_TYPES)[number];

type RankedResult = {
  seed: string;
  score: number;
  evaluation: any; // LogicalMap evaluation (breakdown included)
};

/** ---------- small utilities ---------- */

function randomSeedString() {
  const a = Math.floor(Math.random() * 1e9);
  return `${a}_0`;
}

// stronger randomness (kept; not used by LogicalMap search currently)
function makeRandomSeedStringStrong() {
  const a = crypto.getRandomValues(new Uint32Array(1))[0];
  const b = crypto.getRandomValues(new Uint32Array(1))[0];
  return `${a}_${b}`;
}

function nextFrame() {
  return new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
}

function sumFixedCounts(x: Record<string, number>) {
  return Object.values(x).reduce((a, b) => a + b, 0);
}

/** ---------- sector image helper ---------- */
function normalizeSectorId(id: string) {
  const s = String(id ?? "").trim();
  const t = s.replace(/^0+/, "");
  return t === "" ? "0" : t;
}

function getSectorIdFromAny(obj: any): string | null {
  if (!obj || typeof obj !== "object") return null;

  // よくあるキー揺れを吸収
  const cands = [
    (obj as any).sectorId,
    (obj as any).id,
    (obj as any).tileId,
    (obj as any).sector_id,
    (obj as any).tile_id,
    (obj as any).code,
    (obj as any).name, // 数字が入っているケースの最後の手段
  ];

  for (const v of cands) {
    const s = String(v ?? "").trim();
    if (s && s !== "undefined" && s !== "null") return s;
  }
  return null;
}

function buildSectorImgById() {
  const map: Record<string, string> = {};

  const put = (arr: any[]) => {
    for (const s of arr) {
      const id = getSectorIdFromAny(s);
      if (!id) continue;
      // imgキーも揺れる可能性があるので吸収
      const img = String((s as any).img ?? (s as any).image ?? (s as any).src ?? "");
      map[id] = img;
    }
  };

  put(Array.isArray(BASE_SECTORS) ? (BASE_SECTORS as any[]) : []);
  put(Array.isArray(EXPANSION_MIDDLE) ? (EXPANSION_MIDDLE as any[]) : []);
  put(Array.isArray(EXPANSION_LITTLE) ? (EXPANSION_LITTLE as any[]) : []);
  put(Array.isArray(EXPANSION_SCOUT) ? (EXPANSION_SCOUT as any[]) : []);

  return map;
}


/** ---------- little pool utilities ---------- */

function buildLittlePool(fixedPool: string[], fixedCounts: Record<string, number>, littleSlots: number) {
  const fixedSum = sumFixedCounts(fixedCounts);
  const requiredNonFixed = Math.max(0, littleSlots - fixedSum);

  // candidates: fixedPool (or auto)
  const pool =
    fixedPool.length === 1 && fixedPool[0] === "__AUTO__"
      ? (EXPANSION_LITTLE as any[]).map((s) => String(s.sectorId))
      : fixedPool.slice();

  // remove fixed IDs from non-fixed pool (we treat fixed counts as already reserved)
  const fixedIds = new Set(Object.keys(fixedCounts));
  const availableNonFixed = pool.filter((id) => !fixedIds.has(id));

  return {
    pool,
    requiredNonFixed,
    availableNonFixed: availableNonFixed.length,
  };
}

/** ---------- scout feasibility (kept as-is) ---------- */
function computeScoutFeasibility(template: any, scoutCount: number) {
  // Minimal placeholder — your existing implementation is preserved in the original file.
  // If you already had a real computeScoutFeasibility, keep it. (This file already contains it later in your original.)
  return { maxMinDist: null as number | null };
}

/** ---------- normalize helpers (legacy; kept) ---------- */

type NormalizedCellLike = {
  coordKey: string; // "q,r"
  q: number;
  r: number;

  slotId: string;
  sectorId: string;
  rot: number;

  /** legacy slot-local key */
  tplLocalKey: string;

  /** (legacy) sector-local key */
  localKey?: string;

  kind: string;
  planetType?: string;
  tags: string[];
  neighbors: string[];
};

type NormalizedBoardLike = {
  templateId: string;
  cells: NormalizedCellLike[];
  cellByCoord: Map<string, NormalizedCellLike>;
};

function keyOf(q: number, r: number) {
  return `${q},${r}`;
}

function renderAsciiFromBoardCells(cells: BoardCell[], mode: "planet" | "slot" | "sector") {
  // This is your original helper; it remains in your file.
  // (Your file contains the real implementation below; keep it as-is.)
  return "";
}

function useIsNarrow(width: number) {
  const [narrow, setNarrow] = React.useState(false);
  React.useEffect(() => {
    const f = () => setNarrow(window.innerWidth < width);
    f();
    window.addEventListener("resize", f);
    return () => window.removeEventListener("resize", f);
  }, [width]);
  return narrow;
}

/** ---------- main page ---------- */

export default function Page() {
  const [which, setWhich] = React.useState<"3p" | "4p">("3p");
  const template = which === "3p" ? TEMPLATE_3P_LOSTFLEET : TEMPLATE_4P_LOSTFLEET;

  const [seed, setSeed] = React.useState("0");

  // ===== your existing inputs (kept) =====
  const [fixedScoutCount, setFixedScoutCount] = React.useState(4);

  // little fixed counts (19/20/21)
  const [littleFixedCounts, setLittleFixedCounts] = React.useState<Record<string, number>>({
    "19": 2,
    "20": 1,
    "21": 1,
  });

  // debug/inspector toggles (kept)
  const [showConstraints, setShowConstraints] = React.useState(false);

  // Debug: ASCII dump for verifying placement/neighbors
  const [asciiDumpText, setAsciiDumpText] = React.useState<string>("");

  // Debug: Hex SVG viewer (kept)
  const [showHexDebug, setShowHexDebug] = React.useState(false);
  const [hexShowCoords, setHexShowCoords] = React.useState(false);
  const [hexShowOuterTouch, setHexShowOuterTouch] = React.useState(true);
  const [hexSize, setHexSize] = React.useState(22);

  const [trials, setTrials] = React.useState(500);
  const [keepTop, setKeepTop] = React.useState(20);

  // LogicalMap Hard/Soft options (SSOT-based)
  const [outerSameColorMax, setOuterSameColorMax] = React.useState<number>(2); // H2
  const [centerMode, setCenterMode] = React.useState<"NONE" | "CENTER_7_9" | "CENTER_8">("NONE"); // H4
  const [wTouch, setWTouch] = React.useState<number>(1); // Soft: touch penalty
  const [wOuter, setWOuter] = React.useState<number>(2); // Soft: outer penalty (optional)

  const [wScout, setWScout] = React.useState<number>(1); // Soft: Scout評価（惑星近傍の加点）
  const [scoutRadius, setScoutRadius] = React.useState<number>(2); // Soft: Scout近傍半径（hex距離）
  const [wImbalance, setWImbalance] = React.useState<number>(1); // Soft: 乖離評価の重み（std/range）
  const [imbalanceMetric, setImbalanceMetric] = React.useState<"std" | "range">("std"); // Soft: 乖離指標
  // HARD: borderPlanetCount (legacy inputs kept; not used by LogicalMap search now)
  const [borderMaxAll, setBorderMaxAll] = React.useState<string>("");
  const [borderMaxByType, setBorderMaxByType] = React.useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    for (const pt of BASIC_PLANET_TYPES) init[pt] = "";
    return init;
  });

  const [busy, setBusy] = React.useState(false);
  const [results, setResults] = React.useState<RankedResult[]>([]);
  const [errorMsg, setErrorMsg] = React.useState<string | null>(null);

  const [progressCurrent, setProgressCurrent] = React.useState(0);
  const [progressBest, setProgressBest] = React.useState<number | null>(null);

  const [stats, setStats] = React.useState({
    tried: 0,
    placementOk: 0,
    placementFail: 0,
    expandedOk: 0,
    expandFail: 0,
    hardOk: 0,
    hardFail: 0,
    scoredOk: 0,
    scoreFail: 0,
    kept: 0,
  });

  const [hardFailBy, setHardFailBy] = React.useState<Record<string, number>>({});
  const [hardFailSample, setHardFailSample] = React.useState<Record<string, string>>({});

  // fixed large IDs by template
function normalizeSectorId(id: string) {
  const s = String(id ?? "").trim();
  const t = s.replace(/^0+/, "");
  return t === "" ? "0" : t;
}

function getSectorIdFromAny(obj: any): string | null {
  if (!obj || typeof obj !== "object") return null;

  // まずは想定キー
  const cands = [
    obj.sectorId,
    obj.id,
    obj.tileId,
    obj.sector_id,
    obj.tile_id,
    obj.code,
    obj.name, // 最後の手段（数字で入っている場合）
  ];

  for (const v of cands) {
    const s = String(v ?? "").trim();
    if (s && s !== "undefined" && s !== "null") return s;
  }
  return null;
}

const fixedLarge = React.useMemo(() => {
  const req = which === "3p" ? FIXED_LARGE_3P : FIXED_LARGE_4P;

  // BASE_SECTORS が配列であることを前提にせず、防御
  const base = Array.isArray(BASE_SECTORS) ? (BASE_SECTORS as any[]) : [];

  // 正規化キー -> 実ID の辞書
  const normToActual = new Map<string, string>();
  for (const s of base) {
    const actual = getSectorIdFromAny(s);
    if (!actual) continue;
    normToActual.set(normalizeSectorId(actual), actual);
  }

  // デバッグ用：最初の1件だけ構造を見たい場合は一時的に有効化
  // console.log("[BASE_SECTORS sample]", base[0], "sectorId=", getSectorIdFromAny(base[0]));

  // "__AUTO__" の場合は従来通り（ただし getSectorIdFromAny を使う）
  if (req.length === 1 && req[0] === "__AUTO__") {
    const ids = base.map((s) => getSectorIdFromAny(s)).filter(Boolean) as string[];
    if (ids.length === 0) {
      return { ok: false as const, message: "BASE_SECTORS appears empty or has no usable id field (sectorId/id/tileId...)." };
    }
    return { ok: true as const, ids };
  }

  // FIXED_LARGE を実IDへ解決（"01" -> "1" 等を吸収）
  const resolved: string[] = [];
  for (const id of req) {
    const actual = normToActual.get(normalizeSectorId(id));
    if (!actual) {
      const available = Array.from(normToActual.keys()).sort((a, b) => Number(a) - Number(b));
      return {
        ok: false as const,
        message: `Unknown Large sectorId in FIXED_LARGE: ${id} (normalized=${normalizeSectorId(
          id
        )}). Available(normalized): ${available.length ? available.join(", ") : "(none)"}`,
      };
    }
    resolved.push(actual);
  }

  return { ok: true as const, ids: resolved };
}, [which]);



  // little pool fixed
  const fixedLittlePool = React.useMemo(() => {
    return which === "3p" ? FIXED_LITTLE_POOL_3P : FIXED_LITTLE_POOL_4P;
  }, [which]);

const smallSlotCount = React.useMemo(() => {
  const slots: any[] = Array.isArray((template as any).slots) ? (template as any).slots : [];
  return slots.filter((s) => {
    const accepts: any[] = Array.isArray(s.accepts) ? s.accepts : [];
    return accepts.some((a) => String(a ?? "").toUpperCase() === "SMALL");
  }).length;
}, [template]);

const littleSlotCount = React.useMemo(() => {
  // SSOT: SMALL枠に Scout と Little を同居させる
  return Math.max(0, smallSlotCount - Number(fixedScoutCount ?? 0));
}, [smallSlotCount, fixedScoutCount]);



  const littlePool = React.useMemo(() => buildLittlePool(fixedLittlePool, littleFixedCounts, littleSlotCount), [fixedLittlePool, littleFixedCounts, littleSlotCount]);

  const largeIds = React.useMemo(() => (fixedLarge.ok ? fixedLarge.ids.slice() : []), [fixedLarge]);

  // ids for expansions (kept; your original file computes these properly)
const middleIds = React.useMemo(() => {
  return (Array.isArray(EXPANSION_MIDDLE) ? (EXPANSION_MIDDLE as any[]) : [])
    .map((s) => getSectorIdFromAny(s))
    .filter(Boolean) as string[];
}, []);

const scoutIds = React.useMemo(() => {
  return (Array.isArray(EXPANSION_SCOUT) ? (EXPANSION_SCOUT as any[]) : [])
    .map((s) => getSectorIdFromAny(s))
    .filter(Boolean) as string[];
}, []);

const littleIds = React.useMemo(() => {
  const pool =
    fixedLittlePool.length === 1 && fixedLittlePool[0] === "__AUTO__"
      ? ((Array.isArray(EXPANSION_LITTLE) ? (EXPANSION_LITTLE as any[]) : []).map((s) => getSectorIdFromAny(s)).filter(Boolean) as string[])
      : fixedLittlePool.slice();

  return pool;
}, [fixedLittlePool]);


//  const scoutFeas = React.useMemo(() => computeScoutFeasibility(template as any, fixedScoutCount), [template, fixedScoutCount]);

  const allSectors = React.useMemo(
    () => [
      ...(BASE_SECTORS as any[]),
      ...(EXPANSION_MIDDLE as any[]),
      ...(EXPANSION_LITTLE as any[]),
      ...(EXPANSION_SCOUT as any[]),
    ],
    []
  );

  const sectorById = React.useMemo(() => buildSectorLookup(allSectors), [allSectors]);

React.useEffect(() => {
  if (!sectorById || typeof (sectorById as any).get !== "function") {
    console.error("sectorById is invalid:", sectorById);
  }
}, [sectorById]);

  const sectorImgById = React.useMemo(() => buildSectorImgById(), []);

  const placementBaseResult = React.useMemo(() => {
    try {
      const pl = placementFromSeed({
        slots: (template as any).slots as any,
        largeIds,
        middleIds,
        scoutIds,
        littleIds,
        seed: seed || "0",
        scoutCount: fixedScoutCount,
        littleFixedCounts,
      }) as any[];
      return { ok: true as const, placement: pl };
    } catch (e: any) {
      return { ok: false as const, message: e?.message ? String(e.message) : String(e) };
    }
  }, [template, seed, largeIds, middleIds, scoutIds, littleIds, fixedScoutCount, littleFixedCounts]);

  React.useEffect(() => {
    if (!placementBaseResult.ok) {
      setErrorMsg(placementBaseResult.message);
    }
  }, [placementBaseResult]);

  const placementBase = React.useMemo(() => (placementBaseResult.ok ? placementBaseResult.placement : []), [placementBaseResult]);

  const placementForViewer = React.useMemo(() => {
    return placementBase.map((p) => ({ ...p })) as any as ViewerPlacementItem[];
  }, [placementBase]);

  const imgOffsetBySlotId = React.useMemo(() => {
    return {
      M1: { dx: 14, dy: -118 },
      M2: { dx: 14, dy: -118 },
      M3: { dx: 14, dy: -118 },
      M4: { dx: 14, dy: -118 },
      M5: { dx: 44, dy: -74 },
      M6: { dx: 44, dy: -74 },
      M7: { dx: 44, dy: -74 },
      M8: { dx: 46, dy: -72 },
      S1: { dx: 18, dy: -60 },
      S2: { dx: 18, dy: -60 },
      S3: { dx: 18, dy: -60 },
      S4: { dx: 18, dy: -60 },
      S5: { dx: 18, dy: -60 },
      S6: { dx: 18, dy: -60 },
      S7: { dx: 18, dy: -60 },
      S8: { dx: 18, dy: -60 },
    } as const;
  }, []);

  const rotOffsetsBySlotId = React.useMemo(() => {
    return {
//      M1: { 0: { dx: 0, dy: 0 }, 2: { dx: 47, dy: 77 }, 4: { dx: -43, dy: 75 } },
//      M5: { 0: { dx: 0, dy: 0 }, 2: { dx: 47, dy: 77 }, 4: { dx: -40, dy: 79 } },
      M1: { 0: { dx: 0, dy: 0 }, 2: { dx: 74, dy: 176 }, 4: { dx: -114, dy: 150 } },
      M2: { 0: { dx: 0, dy: 0 }, 2: { dx: 74, dy: 176 }, 4: { dx: -114, dy: 150 } },
      M3: { 0: { dx: 0, dy: 0 }, 2: { dx: 74, dy: 176 }, 4: { dx: -114, dy: 150 } },
      M4: { 0: { dx: 0, dy: 0 }, 2: { dx: 74, dy: 176 }, 4: { dx: -114, dy: 150 } },
      M5: { 1: { dx: 0, dy: 0 }, 3: { dx: -26, dy: 70 }, 5: { dx: 48, dy: 58 }},
      M6: { 1: { dx: 0, dy: 0 }, 3: { dx: -26, dy: 70 }, 5: { dx: 48, dy: 58 }},
      M7: { 1: { dx: 0, dy: 0 }, 3: { dx: -26, dy: 70 }, 5: { dx: 48, dy: 58 }},
      M8: { 1: { dx: 0, dy: 0 }, 3: { dx: -26, dy: 70 }, 5: { dx: 48, dy: 58 }},
    } as const;
  }, []);

  // ==== LogicalMap search (Hard→Soft→Rank) ====
  async function handleGenerateRank() {
    if (busy) return;

    if (!fixedLarge.ok) {
      setErrorMsg(fixedLarge.message);
      return;
    }

    setErrorMsg(null);
    setBusy(true);

    setResults([]);
    setProgressCurrent(0);
    setProgressBest(null);

    // legacy stats are kept for UI continuity; we reset them but do not update fine-grained counters here.
    setStats({ tried: 0, placementOk: 0, placementFail: 0, expandedOk: 0, expandFail: 0, hardOk: 0, hardFail: 0, scoredOk: 0, scoreFail: 0, kept: 0 });
    setHardFailBy({});
    setHardFailSample({});

    await nextFrame();

    try {
      const logicalTemplateId = which === "3p" ? "3p_lostFleet" : "4p_lostFleet";

      const { results: best, diagnostics } = await runLogicalSearch(
        logicalTemplateId,
        {
          trials,
          keepTop,
          seedStart: 1,
          yieldEvery: 50,
          hard: {
            minSameColorDist: 3,
            outerSameColorMax,
            centerMode,
          },
          soft: {
            wOuter,
            wTouch,
            wScout,
            scoutRadius,
            wImbalance,
            imbalanceMetric,
          },
        },
        (done, bestNow) => {
          setProgressCurrent(done);

          const mapped: RankedResult[] = (bestNow as any[]).map((x: any) => ({
            seed: String(x.seed),
            score: Number(x.score ?? 0),
            evaluation: {
              total: Number(x.score ?? 0),
              breakdown: x.breakdown,
              audit: x.audit,
            },
          }));

          setResults(mapped);
          setProgressBest(mapped.length > 0 ? mapped[0].score : null);
        }
      );

      const mappedFinal: RankedResult[] = (best as any[]).map((x: any) => ({
        seed: String(x.seed),
        score: Number(x.score ?? 0),
        evaluation: {
          total: Number(x.score ?? 0),
          breakdown: x.breakdown,
          audit: x.audit,
        },
      }));
setResults(mappedFinal);
      if ((diagnostics as any)?.hardFailBy) {
        const hf = (diagnostics as any).hardFailBy;
        setHardFailBy({
          buildLogicalMapFailed: 0,
          H1: hf.H1_MIN_DIST ?? 0,
          H2: hf.H2_OUTER_CAP ?? 0,
          H4: hf.H4_CENTER_LARGE14 ?? 0,
        });
      }
      setProgressCurrent(trials);
      setProgressBest(mappedFinal.length > 0 ? mappedFinal[0].score : null);

      if (mappedFinal.length > 0) setSeed(String(mappedFinal[0].seed));

      if ((diagnostics as any)?.firstBuildError) {
        console.warn("[LogicalSearch first build error]", (diagnostics as any).firstBuildError);
      }
    } catch (e: any) {
      console.error(e);
      setErrorMsg(e?.message ? String(e.message) : String(e));
    } finally {
      setBusy(false);
    }
  }

  const progressPct = trials > 0 ? Math.max(0, Math.min(1, progressCurrent / trials)) : 0;

//  const scoutFeasMsg = React.useMemo(() => {
//    const mm = (scoutFeas as any).maxMinDist;
//    if (mm === null) return "Scout feasibility: N/A";
//    const ok = mm >= 4;
//    return `Scout feasibility: maxMinDist=${mm} (${ok ? "minScoutDist=4 is POSSIBLE" : "minScoutDist=4 is IMPOSSIBLE"})`;
//  }, [scoutFeas]);

  const isNarrow = useIsNarrow(1180);

  return (
    <div style={{ width: "100%", height: "100vh", display: "flex", flexDirection: "column" }}>
      <div style={{ padding: 12, display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
        <div style={{ fontWeight: 700 }}>Board Export</div>

        <label style={{ display: "flex", gap: 6, alignItems: "center" }}>
          <span>Template</span>
          <select value={which} onChange={(e) => setWhich(e.target.value as any)}>
            <option value="3p">3p Lost Fleet</option>
            <option value="4p">4p Lost Fleet</option>
          </select>
        </label>

        <label style={{ display: "flex", gap: 6, alignItems: "center" }}>
          <span>Seed</span>
          <input value={seed} onChange={(e) => setSeed(e.target.value)} style={{ width: 160 }} />
        </label>

        <button onClick={() => setSeed(randomSeedString())} style={{ padding: "6px 10px" }}>
          Random Seed
        </button>

        <button onClick={handleGenerateRank} disabled={busy} style={{ padding: "6px 10px", fontWeight: 700 }}>
          {busy ? "Searching..." : "Run Search (LogicalMap)"}
        </button>

        <div style={{ fontSize: 12, opacity: 0.8 }}>
          progress: {progressCurrent}/{trials} ({Math.round(progressPct * 100)}%) / best={progressBest ?? "-"}
        </div>

        <label style={{ display: "flex", gap: 6, alignItems: "center" }}>
          <input type="checkbox" checked={showConstraints} onChange={(e) => setShowConstraints(e.target.checked)} />
          <span>Constraints inspector</span>
        </label>
      </div>

      <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
        <div style={{ flex: 1, overflow: "auto", padding: 6, display: "flex", flexDirection: isNarrow ? "column" : "row", gap: 12 }}>
<div style={{ flex: 1, minWidth: 520, display: "flex", flexDirection: "column", minHeight: 0 }}>
  <div
    style={{
      border: "1px solid #ddd",
      borderRadius: 8,
      // ★ここが大きい余白の元：Map領域はpaddingを消す
      padding: 0,
      // ★縦方向に「タイトル＋ビューア」で割る
      display: "flex",
      flexDirection: "column",
      minHeight: 0,
      flex: 1,
      overflow: "hidden",
    }}
  >
    {/* タイトル行（固定） */}
    <div style={{ padding: 12, borderBottom: "1px solid #eee" }}>
      <div style={{ fontWeight: 700 }}>Map Output</div>
    </div>

    {/* ★ビューア領域（残り高さを全部使う） */}
    <div style={{ flex: 1, minHeight: 0, overflow: "hidden" }}>
      <MapBoardViewer
        template={template as any}
        placement={placementForViewer as any}
        sectorById={sectorById as any}
        sectorImgById={sectorImgById as any}
        imgOffsetBySlotId={imgOffsetBySlotId as any}
        rotOffsetsBySlotId={rotOffsetsBySlotId as any}
        scaleByAccepts={{ LARGE: 1.0, MIDDLE: 0.92, SMALL: 1.0 }}
        boundsPad={20}   // ★ここも詰める（80→20推奨）
        zoom={1}      // ★少し上げるとさらに余白感が減る
      />
    </div>
  </div>

            <div style={{ marginTop: 12, border: "1px solid #ddd", borderRadius: 8, padding: 12 }}>
              <div style={{ fontWeight: 700 }}>Debug / Inspector</div>

              {errorMsg ? (
                <div style={{ marginTop: 8, color: "crimson", whiteSpace: "pre", overflowX: "auto" }}>{errorMsg}</div>
              ) : (
                <div style={{ marginTop: 8, fontSize: 12, opacity: 0.8 }}>OK</div>
              )}


              {!fixedLarge.ok && (
                <div style={{ marginTop: 10, fontSize: 12, color: "crimson", whiteSpace: "pre", overflowX: "auto" }}>
                  {fixedLarge.message}
                </div>
              )}

<div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
  <div style={{ fontWeight: 700, fontSize: 12 }}>Little fixed counts</div>

  {(["19", "20", "21"] as const).map((id) => (
    <label key={id} style={{ fontSize: 12 }}>
      {id}
      <input
        type="number"
        min={0}
        value={Number(littleFixedCounts[id] ?? 0)}
        onChange={(e) =>
          setLittleFixedCounts((prev) => ({
            ...prev,
            [id]: Number(e.target.value),
          }))
        }
        style={{ width: 70, marginLeft: 6 }}
      />
    </label>
  ))}

  <div style={{ fontSize: 11, opacity: 0.8 }}>
    total={Object.values(littleFixedCounts).reduce((a, b) => a + (Number(b) || 0), 0)} / littleSlots={littleSlotCount}
  </div>
</div>


              <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap", alignItems: "center" }}>
                <label style={{ fontSize: 12 }}>
                  Trials
                  <input type="number" value={trials} onChange={(e) => setTrials(Number(e.target.value))} style={{ width: 90, marginLeft: 6 }} />
                </label>
                <label style={{ fontSize: 12 }}>
                  Keep
                  <input type="number" value={keepTop} onChange={(e) => setKeepTop(Number(e.target.value))} style={{ width: 90, marginLeft: 6 }} />
                </label>

                <label style={{ fontSize: 12 }}>
                  H2 outerSameColorMax
                  <input
                    type="number"
                    value={outerSameColorMax}
                    onChange={(e) => setOuterSameColorMax(Number(e.target.value))}
                    style={{ width: 90, marginLeft: 6 }}
                  />
                </label>

                <label style={{ fontSize: 12 }}>
                  H4 centerMode
                  <select value={centerMode} onChange={(e) => setCenterMode(e.target.value as any)} style={{ marginLeft: 6 }}>
                    <option value="NONE">NONE</option>
                    <option value="CENTER_7_9">CENTER_7_9 (L7,L8,L9)</option>
                    <option value="CENTER_8">CENTER_8 (L8 only)</option>
                  </select>
                </label>

                <label style={{ fontSize: 12 }}>
                  Soft wTouch
                  <input
                    type="number"
                    value={wTouch}
                    onChange={(e) => setWTouch(Number(e.target.value))}
                    style={{ width: 90, marginLeft: 6 }}
                  />
                </label>

                <label style={{ fontSize: 12 }}>
                  Soft wOuter
                  <input
                    type="number"
                    value={wOuter}
                    onChange={(e) => setWOuter(Number(e.target.value))}
                    style={{ width: 90, marginLeft: 6 }}
                  />
                </label>

                
                <label style={{ fontSize: 12 }}>
                  Soft wScout
                  <input
                    type="number"
                    value={wScout}
                    onChange={(e) => setWScout(Number(e.target.value))}
                    style={{ width: 90, marginLeft: 6 }}
                  />
                </label>

                <label style={{ fontSize: 12 }}>
                  Soft scoutRadius
                  <input
                    type="number"
                    value={scoutRadius}
                    onChange={(e) => setScoutRadius(Number(e.target.value))}
                    style={{ width: 90, marginLeft: 6 }}
                  />
                </label>

                <label style={{ fontSize: 12 }}>
                  Soft wImbalance
                  <input
                    type="number"
                    value={wImbalance}
                    onChange={(e) => setWImbalance(Number(e.target.value))}
                    style={{ width: 90, marginLeft: 6 }}
                  />
                </label>

                <label style={{ fontSize: 12 }}>
                  Soft imbalanceMetric
                  <select
                    value={imbalanceMetric}
                    onChange={(e) => setImbalanceMetric(e.target.value as any)}
                    style={{ marginLeft: 6 }}
                  >
                    <option value="std">std</option>
                    <option value="range">range</option>
                  </select>
                </label>
<div style={{ display: "flex", flexDirection: "column", gap: 6, padding: 8, border: "1px solid #ddd", borderRadius: 8 }}>
                  <div style={{ fontWeight: 700, fontSize: 12 }}>Legacy HARD inputs (kept)</div>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
                    <label style={{ fontSize: 12 }}>
                      borderMaxAll
                      <input type="number" value={borderMaxAll} onChange={(e) => setBorderMaxAll(e.target.value)} style={{ width: 90, marginLeft: 6 }} />
                    </label>
                    {BASIC_PLANET_TYPES.map((pt) => (
                      <label key={pt} style={{ fontSize: 12 }}>
                        {pt}
                        <input
                          type="number"
                          value={borderMaxByType[pt]}
                          onChange={(e) => setBorderMaxByType((prev) => ({ ...prev, [pt]: e.target.value }))}
                          style={{ width: 70, marginLeft: 6 }}
                        />
                      </label>
                    ))}
                  </div>
                </div>

                <button onClick={() => setShowHexDebug((v) => !v)} style={{ padding: "6px 10px" }}>
                  {showHexDebug ? "Hide Hex Debug" : "Show Hex Debug"}
                </button>

                <button
                  onClick={() => {
                    const placementForExpand = (placementForViewer as any[]).map((x: any) => ({
                      slotId: String(x.slotId),
                      sectorId: String(x.sectorId),
                      rot: Number(x.rot ?? 0),
                    }));

                    const boardCells = expandPlacementToBoardCells({
                      slots: (template as any).slots,
                      placement: placementForExpand,
                      sectorById,
                    });

                    const txt = renderAsciiFromBoardCells(boardCells as any, "slot");
                    setAsciiDumpText(txt);
                  }}
                  style={{ padding: "6px 10px" }}
                >
                  Dump (slot) - current board
                </button>
              </div>

              <div style={{ marginTop: 10 }}>
                <div style={{ fontWeight: 700, fontSize: 12 }}>Hard Reject Counts (LogicalMap search)</div>
                <pre style={{ margin: 0, fontSize: 12, whiteSpace: "pre", overflowX: "auto" }}>{JSON.stringify(hardFailBy, null, 2)}</pre>
              </div>

              {asciiDumpText ? (
                <div style={{ marginTop: 10 }}>
                  <div style={{ fontWeight: 700, fontSize: 12 }}>ASCII Dump</div>
                  <pre style={{ margin: 0, fontSize: 12, whiteSpace: "pre", overflowX: "auto" }}>{asciiDumpText}</pre>
                </div>
              ) : null}
            </div>
          </div>

          <div style={{ width: isNarrow ? "100%" : 520, flexShrink: 0, display: "flex", flexDirection: "column", gap: 12 }}>
            <div style={{ padding: 12, border: "1px solid #ddd", borderRadius: 8, width: "100%" }}>
              <div style={{ fontWeight: 700 }}>Pools</div>
              <div style={{ marginTop: 8, fontSize: 12 }}>Large (fixed): {largeIds.join(", ")}</div>
              <div style={{ marginTop: 4, fontSize: 12 }}>Middle: {middleIds.join(", ")}</div>
              <div style={{ marginTop: 4, fontSize: 12 }}>Scout: {scoutIds.join(", ")}</div>
              <div style={{ marginTop: 4, fontSize: 12, whiteSpace: "pre", overflowX: "auto" }}>Little pool: {littleIds.join(", ")}</div>
              <div style={{ marginTop: 4, fontSize: 11, opacity: 0.8 }}>
                littleSlots={littleSlotCount} ・ fixedSum={sumFixedCounts(littleFixedCounts)} ・ nonFixedRequired={littlePool.requiredNonFixed} ・ nonFixedAvailable={littlePool.availableNonFixed}
              </div>
            </div>

            <div style={{ padding: 12, border: "1px solid #ddd", borderRadius: 8, width: "100%" }}>
              <div style={{ fontWeight: 700 }}>Results</div>
              {results.length === 0 ? (
                <div style={{ marginTop: 6, fontSize: 12, opacity: 0.7 }}>No results yet</div>
              ) : (
                <div style={{ marginTop: 6 }}>
                  {results.map((r, i) => (
                    <div
                      key={`${r.seed}-${i}`}
                      style={{
                        display: "flex",
                        gap: 8,
                        alignItems: "center",
                        fontSize: 12,
                        padding: "4px 0",
                        borderBottom: "1px dashed #eee",
                      }}
                    >
                      <div style={{ width: 24, textAlign: "right" }}>{i + 1}</div>
                      <button onClick={() => setSeed(String(r.seed))} style={{ padding: "2px 6px" }}>
                        Use
                      </button>
                      <div>seed={String(r.seed)}</div>
                      <div style={{ marginLeft: "auto", textAlign: "right" }}>
                        <div>score={Math.round((r.score ?? 0) * 100) / 100}</div>
                        <div style={{ fontSize: 11, opacity: 0.8 }}>
                          outerCnt={r.evaluation?.breakdown?.outerTouchPenalty?.outerNormalCount ?? 0} ・ touchCnt=
                          {r.evaluation?.breakdown?.outerTouchPenalty?.touchNormalCount ?? 0}
                        </div>
                        <div style={{ fontSize: 11, opacity: 0.8 }}>
                          outerPen={r.evaluation?.breakdown?.outerTouchPenalty?.penaltyOuter ?? 0} ・ touchPen=
                          {r.evaluation?.breakdown?.outerTouchPenalty?.penaltyTouch ?? 0}
                        </div>
                      </div>
                      <details style={{ marginLeft: 8 }}>
                        <summary style={{ cursor: "pointer", fontSize: 11, opacity: 0.8 }}>breakdown</summary>
                        <pre style={{ margin: 0, fontSize: 11, maxWidth: 520, whiteSpace: "pre", overflowX: "auto" }}>
                          {JSON.stringify(r.evaluation?.breakdown ?? r.evaluation ?? null, null, 2)}
                        </pre>
                      </details>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {showConstraints && (
              <ConstraintInspector
                template={template as any}
                placement={placementForViewer as any}
                sectorById={sectorById as any}
                largeIds={largeIds}
                middleIds={middleIds}
                scoutIds={scoutIds}
                littleIds={littleIds}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function ConstraintInspector(props: any) {
  const report: ConstraintReport = React.useMemo(() => {
    return computeConstraintReport({
      slots: props.template.slots as any,
      placements: props.placement as any,
      largeIds: props.largeIds,
      middleIds: props.middleIds,
      scoutIds: props.scoutIds,
      littleIds: props.littleIds,
    } as any);
  }, [props.template, props.placement, props.largeIds, props.middleIds, props.scoutIds, props.littleIds]);

  return (
    <div style={{ padding: 12, border: "1px solid #ddd", borderRadius: 8, width: "100%" }}>
      <div style={{ fontWeight: 700 }}>Constraint Inspector</div>

      <div style={{ marginTop: 10 }}>
        <div style={{ fontWeight: 700, fontSize: 12 }}>Pool Summary</div>
        <table style={{ width: "100%", fontSize: 12, marginTop: 6 }}>
          <thead>
            <tr>
              <th style={{ textAlign: "left" }}>Kind</th>
              <th style={{ textAlign: "right" }}>Need</th>
              <th style={{ textAlign: "right" }}>Candidates</th>
              <th style={{ textAlign: "right" }}>Units</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>LARGE</td>
              <td style={{ textAlign: "right" }}>{report.pool.need.LARGE}</td>
              <td style={{ textAlign: "right" }}>{report.pool.candidates.LARGE}</td>
              <td style={{ textAlign: "right" }}>{report.pool.units.LARGE}</td>
            </tr>
            <tr>
              <td>MIDDLE</td>
              <td style={{ textAlign: "right" }}>{report.pool.need.MIDDLE}</td>
              <td style={{ textAlign: "right" }}>{report.pool.units.MIDDLE}</td>
              <td style={{ textAlign: "right" }}>{report.pool.units.MIDDLE}</td>
            </tr>
            <tr>
              <td>SCOUT</td>
              <td style={{ textAlign: "right" }}>—</td>
              <td style={{ textAlign: "right" }}>{report.pool.candidates.SCOUT}</td>
              <td style={{ textAlign: "right" }}>—</td>
            </tr>
            <tr>
              <td>LITTLE</td>
              <td style={{ textAlign: "right" }}>fill</td>
              <td style={{ textAlign: "right" }}>{report.pool.candidates.LITTLE}</td>
              <td style={{ textAlign: "right" }}>—</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
